USE [C:\USERS\DEP\DOCUMENTS\ITEC 499\BACKUP\NEW FOLDER (2)\OAHMS - V3\OAHMS\BIN\DEBUG\OAHMS.MDF]
GO

/****** Object: Table [dbo].[Billing_Details] Script Date: 2/26/2020 6:40:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Billing_Details] (
    [Invoice Number] INT          NOT NULL,
    [Resident Name]  VARCHAR (50) NOT NULL,
    [Address]        VARCHAR (50) NOT NULL,
    [Invoice Date]   DATE         NOT NULL,
    [Description]    VARCHAR (50) NOT NULL,
    [Quantity]       INT          NOT NULL,
    [Unit Price]     NUMERIC (18) NOT NULL,
    [Subtotal]       NUMERIC (18) NOT NULL,
    [Amount]         NUMERIC (18) NOT NULL
);


