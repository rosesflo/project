USE [C:\USERS\DEP\DOCUMENTS\ITEC 499\BACKUP\NEW FOLDER (2)\OAHMS - V3\OAHMS\BIN\DEBUG\OAHMS.MDF]
GO

/****** Object: Table [dbo].[Employees] Script Date: 2/26/2020 6:41:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Employees] (
    [Emp_Id]    INT          IDENTITY (1, 1) NOT NULL,
    [Emp_Name]  VARCHAR (50) NOT NULL,
    [Emp_Title] VARCHAR (25) NOT NULL,
    [Emp_Addr]  VARCHAR (50) NOT NULL,
    [Volunteer] VARCHAR (5)  NOT NULL,
    [Emp_Notes] VARCHAR (50) NOT NULL,
    [Emp_Qual]  VARCHAR (50) NOT NULL
);


