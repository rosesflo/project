USE [C:\USERS\DEP\DOCUMENTS\ITEC 499\BACKUP\NEW FOLDER (2)\OAHMS - V3\OAHMS\BIN\DEBUG\OAHMS.MDF]
GO

/****** Object: Table [dbo].[Resident_Details] Script Date: 2/26/2020 6:42:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Resident_Details] (
    [R_Id]          INT          IDENTITY (1, 1) NOT NULL,
    [R_Name]        VARCHAR (50) NOT NULL,
    [RM_Number]     INT          NOT NULL,
    [RM_Type]       VARCHAR (25) NOT NULL,
    [R_Sex]         VARCHAR (15) NOT NULL,
    [R_Age]         INT          NOT NULL,
    [R_DateOfBirth] DATE         NOT NULL,
    [R_Status]      VARCHAR (25) NOT NULL,
    [R_Hobbies]     VARCHAR (50) NOT NULL,
    [R_PrevProf]    VARCHAR (50) NOT NULL,
    [R_Disability]  VARCHAR (50) NOT NULL,
    [R_Deceased]    VARCHAR (5)  NOT NULL,
    [R_DateOfDeath] DATE         NOT NULL,
    [R_NOK]         VARCHAR (50) NOT NULL,
    [R_JoinDate]    DATE         NOT NULL,
    [R_Notes]       VARCHAR (50) NOT NULL,
    [R_LeftDate]    DATE         NOT NULL
);


