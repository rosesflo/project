USE [C:\USERS\DEP\DOCUMENTS\ITEC 499\BACKUP\NEW FOLDER (2)\OAHMS - V3\OAHMS\BIN\DEBUG\OAHMS.MDF]
GO

/****** Object: Table [dbo].[Next_of_Kin] Script Date: 2/26/2020 6:41:51 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Next_of_Kin] (
    [Id]        INT          IDENTITY (1, 1) NOT NULL,
    [NOK_Name]  VARCHAR (50) NOT NULL,
    [NOK_Addr]  VARCHAR (50) NOT NULL,
    [NOK_Phone] VARCHAR (15) NOT NULL,
    [NOK_Email] VARCHAR (50) NOT NULL,
    [R_Name]    VARCHAR (50) NOT NULL
);


