USE [C:\USERS\DEP\DOCUMENTS\ITEC 499\BACKUP\NEW FOLDER (2)\OAHMS - V3\OAHMS\BIN\DEBUG\OAHMS.MDF]
GO

/****** Object: Table [dbo].[Resident] Script Date: 2/26/2020 6:42:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Resident] (
    [R_Id]        INT          IDENTITY (1, 1) NOT NULL,
    [R_Name]      VARCHAR (50) NOT NULL,
    [R_Addr]      VARCHAR (50) NOT NULL,
    [R_Religion]  VARCHAR (50) NOT NULL,
    [R_Allergies] VARCHAR (50) NOT NULL,
    [R_NextOfKin] VARCHAR (50) NOT NULL,
    [R_Notes]     VARCHAR (50) NOT NULL
);


