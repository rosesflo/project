USE [C:\USERS\DEP\DOCUMENTS\ITEC 499\BACKUP\NEW FOLDER (2)\OAHMS - V3\OAHMS\BIN\DEBUG\OAHMS.MDF]
GO

/****** Object: Table [dbo].[Home] Script Date: 2/26/2020 6:41:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Home] (
    [Home_Id]      INT          IDENTITY (1, 1) NOT NULL,
    [Home_Name]    VARCHAR (50) NOT NULL,
    [Home_Addr]    VARCHAR (50) NOT NULL,
    [Home_Phone]   VARCHAR (15) NOT NULL,
    [Home_Email]   VARCHAR (50) NOT NULL,
    [Home_Manager] VARCHAR (50) NOT NULL
);


