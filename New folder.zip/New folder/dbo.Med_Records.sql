USE [C:\USERS\DEP\DOCUMENTS\ITEC 499\BACKUP\NEW FOLDER (2)\OAHMS - V3\OAHMS\BIN\DEBUG\OAHMS.MDF]
GO

/****** Object: Table [dbo].[Med_Records] Script Date: 2/26/2020 6:41:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Med_Records] (
    [R_Id]          INT          NOT NULL,
    [R_Name]        VARCHAR (50) NOT NULL,
    [Med_Physician] VARCHAR (50) NOT NULL,
    [Date]          DATE         NOT NULL,
    [Time]          TIME (7)     NOT NULL,
    [M_Condition]   VARCHAR (50) NOT NULL,
    [P_Condition]   VARCHAR (50) NOT NULL,
    [Notes]         VARCHAR (50) NOT NULL
);


