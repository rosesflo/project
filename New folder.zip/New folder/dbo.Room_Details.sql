USE [C:\USERS\DEP\DOCUMENTS\ITEC 499\BACKUP\NEW FOLDER (2)\OAHMS - V3\OAHMS\BIN\DEBUG\OAHMS.MDF]
GO

/****** Object: Table [dbo].[Room_Details] Script Date: 2/26/2020 6:42:29 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Room_Details] (
    [RM_ID]     INT          IDENTITY (1, 1) NOT NULL,
    [RM_Number] INT          NOT NULL,
    [RM_Type]   VARCHAR (25) NOT NULL,
    [Available] VARCHAR (25) NOT NULL,
    [R_Name]    VARCHAR (50) NOT NULL
);


