USE [C:\USERS\DEP\DOCUMENTS\ITEC 499\BACKUP\NEW FOLDER (2)\OAHMS - V3\OAHMS\BIN\DEBUG\OAHMS.MDF]
GO

/****** Object: Table [dbo].[Emp_Details] Script Date: 2/26/2020 6:41:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Emp_Details] (
    [Emp_Id]       INT          NOT NULL,
    [Emp_Name]     VARCHAR (50) NOT NULL,
    [Emp_Addr]     VARCHAR (50) NOT NULL,
    [Emp_Gender]   VARCHAR (25) NOT NULL,
    [Emp_Age]      INT          NOT NULL,
    [Emp_DoB]      DATE         NOT NULL,
    [Emp_JobTitle] VARCHAR (50) NOT NULL,
    [Emp_HireDate] DATE         NOT NULL,
    [Emp_Salary]   NUMERIC (18) NOT NULL,
    [Emp_Phone]    VARCHAR (15) NOT NULL,
    [Emp_Status]   VARCHAR (25) NOT NULL,
    [Emp_Email]    VARCHAR (50) NOT NULL,
    [Emp_NisNmbr]  VARCHAR (50) NOT NULL,
    [Emp_HomeID]   INT          NOT NULL
);


