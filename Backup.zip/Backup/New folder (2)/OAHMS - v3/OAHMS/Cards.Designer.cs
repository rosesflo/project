﻿namespace OAHMS
{
    partial class frm_Cards
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Cards));
            this.btn_activity = new System.Windows.Forms.Button();
            this.btn_employee = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.btn_nok = new System.Windows.Forms.Button();
            this.btn_residentCard = new System.Windows.Forms.Button();
            this.btn_room = new System.Windows.Forms.Button();
            this.btn_user = new System.Windows.Forms.Button();
            this.btn_rtnMain = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_activity
            // 
            this.btn_activity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_activity.Location = new System.Drawing.Point(57, 13);
            this.btn_activity.Name = "btn_activity";
            this.btn_activity.Size = new System.Drawing.Size(137, 23);
            this.btn_activity.TabIndex = 0;
            this.btn_activity.Text = "Activity Card";
            this.btn_activity.UseVisualStyleBackColor = true;
            this.btn_activity.Click += new System.EventHandler(this.btn_activity_Click);
            // 
            // btn_employee
            // 
            this.btn_employee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_employee.Location = new System.Drawing.Point(57, 42);
            this.btn_employee.Name = "btn_employee";
            this.btn_employee.Size = new System.Drawing.Size(137, 23);
            this.btn_employee.TabIndex = 1;
            this.btn_employee.Text = "Employee Card";
            this.btn_employee.UseVisualStyleBackColor = true;
            this.btn_employee.Click += new System.EventHandler(this.btn_employee_Click);
            // 
            // btn_home
            // 
            this.btn_home.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_home.Location = new System.Drawing.Point(57, 70);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(137, 23);
            this.btn_home.TabIndex = 2;
            this.btn_home.Text = "Home Card";
            this.btn_home.UseVisualStyleBackColor = true;
            // 
            // btn_nok
            // 
            this.btn_nok.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_nok.Location = new System.Drawing.Point(57, 99);
            this.btn_nok.Name = "btn_nok";
            this.btn_nok.Size = new System.Drawing.Size(137, 23);
            this.btn_nok.TabIndex = 3;
            this.btn_nok.Text = "Next of Kin Card";
            this.btn_nok.UseVisualStyleBackColor = true;
            this.btn_nok.Click += new System.EventHandler(this.btn_nok_Click);
            // 
            // btn_residentCard
            // 
            this.btn_residentCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_residentCard.Location = new System.Drawing.Point(57, 128);
            this.btn_residentCard.Name = "btn_residentCard";
            this.btn_residentCard.Size = new System.Drawing.Size(137, 23);
            this.btn_residentCard.TabIndex = 4;
            this.btn_residentCard.Text = "Resident Card";
            this.btn_residentCard.UseVisualStyleBackColor = true;
            this.btn_residentCard.Click += new System.EventHandler(this.btn_residentCard_Click);
            // 
            // btn_room
            // 
            this.btn_room.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_room.Location = new System.Drawing.Point(57, 161);
            this.btn_room.Name = "btn_room";
            this.btn_room.Size = new System.Drawing.Size(137, 23);
            this.btn_room.TabIndex = 5;
            this.btn_room.Text = "Room Card";
            this.btn_room.UseVisualStyleBackColor = true;
            this.btn_room.Click += new System.EventHandler(this.btn_room_Click);
            // 
            // btn_user
            // 
            this.btn_user.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_user.Location = new System.Drawing.Point(57, 190);
            this.btn_user.Name = "btn_user";
            this.btn_user.Size = new System.Drawing.Size(137, 23);
            this.btn_user.TabIndex = 6;
            this.btn_user.Text = "Users Card";
            this.btn_user.UseVisualStyleBackColor = true;
            // 
            // btn_rtnMain
            // 
            this.btn_rtnMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rtnMain.Location = new System.Drawing.Point(57, 234);
            this.btn_rtnMain.Name = "btn_rtnMain";
            this.btn_rtnMain.Size = new System.Drawing.Size(137, 23);
            this.btn_rtnMain.TabIndex = 7;
            this.btn_rtnMain.Text = "Return to Main";
            this.btn_rtnMain.UseVisualStyleBackColor = true;
            this.btn_rtnMain.Click += new System.EventHandler(this.btn_rtnMain_Click);
            // 
            // frm_Cards
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.ClientSize = new System.Drawing.Size(247, 275);
            this.Controls.Add(this.btn_rtnMain);
            this.Controls.Add(this.btn_user);
            this.Controls.Add(this.btn_room);
            this.Controls.Add(this.btn_residentCard);
            this.Controls.Add(this.btn_nok);
            this.Controls.Add(this.btn_home);
            this.Controls.Add(this.btn_employee);
            this.Controls.Add(this.btn_activity);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_Cards";
            this.Text = "Cards";
            this.Load += new System.EventHandler(this.frm_Cards_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_activity;
        private System.Windows.Forms.Button btn_employee;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button btn_nok;
        private System.Windows.Forms.Button btn_residentCard;
        private System.Windows.Forms.Button btn_room;
        private System.Windows.Forms.Button btn_user;
        private System.Windows.Forms.Button btn_rtnMain;
    }
}