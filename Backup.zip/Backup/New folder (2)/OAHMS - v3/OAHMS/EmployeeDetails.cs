﻿using System;
using System.Windows.Forms;

namespace OAHMS
{
    public partial class frmEmpDetails : Form
    {
        public frmEmpDetails()
        {
            InitializeComponent();
        }

        //form load
        private void EmployeeDetails_Load(object sender, EventArgs e)
        {

        }
    }
}
