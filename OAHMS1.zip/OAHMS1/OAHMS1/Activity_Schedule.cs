﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Activity_Schedule : Form
    {
        public Activity_Schedule()
        {
            InitializeComponent();
        }

        private void tbl_ActivityScheduleBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_ActivityScheduleBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet1);

        }

        private void Activity_Schedule_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet1.tbl_ActivitySchedule' table. You can move, or remove it, as needed.
            this.tbl_ActivityScheduleTableAdapter.Fill(this.databaseDataSet1.tbl_ActivitySchedule);

        }
    }
}
