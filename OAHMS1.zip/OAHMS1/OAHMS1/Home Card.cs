﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Home_Card : Form
    {
        public Home_Card()
        {
            InitializeComponent();
        }

        private void tbl_HomeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_HomeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet8);

        }

        private void Home_Card_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet8.tbl_Home' table. You can move, or remove it, as needed.
            this.tbl_HomeTableAdapter.Fill(this.databaseDataSet8.tbl_Home);

        }
    }
}
