﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Resident_Card : Form
    {
        public Resident_Card()
        {
            InitializeComponent();
        }

        private void tbl_ResidentsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_ResidentsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet18);

        }

        private void Resident_Card_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet18.tbl_Residents' table. You can move, or remove it, as needed.
            this.tbl_ResidentsTableAdapter.Fill(this.databaseDataSet18.tbl_Residents);

        }
    }
}
