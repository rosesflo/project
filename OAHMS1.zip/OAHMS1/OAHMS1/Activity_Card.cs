﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OAHMS1
{
    public partial class Activity_Card : Form
    {
        public Activity_Card()
        {
            InitializeComponent();
        }

        private void tbl_ActivityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_ActivityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet);

        }

        private void Activity_Card_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet.tbl_Activity' table. You can move, or remove it, as needed.
            this.tbl_ActivityTableAdapter.Fill(this.databaseDataSet.tbl_Activity);

        }

        private void btnAddRecord_Click(object sender, EventArgs e)
        {
            this.tbl_ActivityBindingSource.AddNew();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_ActivityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            this.tbl_ActivityBindingSource.RemoveCurrent();
        }
    }
}
