﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Staff_Records : Form
    {
        public Staff_Records()
        {
            InitializeComponent();
        }

        private void tbl_StaffRecordsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_StaffRecordsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet20);

        }

        private void Staff_Records_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet20.tbl_StaffRecords' table. You can move, or remove it, as needed.
            this.tbl_StaffRecordsTableAdapter.Fill(this.databaseDataSet20.tbl_StaffRecords);

        }
    }
}
