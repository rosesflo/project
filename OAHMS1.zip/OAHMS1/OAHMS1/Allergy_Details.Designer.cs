﻿namespace OAHMS1
{
    partial class Allergy_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label noteLabel;
            System.Windows.Forms.Label foodLabel;
            System.Windows.Forms.Label drugLabel;
            System.Windows.Forms.Label iDLabel;
            System.Windows.Forms.Label rIDLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Allergy_Details));
            this.databaseDataSet5 = new OAHMS1.DatabaseDataSet5();
            this.tbl_AllergyDetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_AllergyDetailTableAdapter = new OAHMS1.DatabaseDataSet5TableAdapters.tbl_AllergyDetailTableAdapter();
            this.tableAdapterManager = new OAHMS1.DatabaseDataSet5TableAdapters.TableAdapterManager();
            this.tbl_AllergyDetailBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_AllergyDetailBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.noteTextBox = new System.Windows.Forms.TextBox();
            this.foodTextBox = new System.Windows.Forms.TextBox();
            this.drugTextBox = new System.Windows.Forms.TextBox();
            this.iDTextBox = new System.Windows.Forms.TextBox();
            this.rIDTextBox = new System.Windows.Forms.TextBox();
            this.tbl_AllergyDetailDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            noteLabel = new System.Windows.Forms.Label();
            foodLabel = new System.Windows.Forms.Label();
            drugLabel = new System.Windows.Forms.Label();
            iDLabel = new System.Windows.Forms.Label();
            rIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_AllergyDetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_AllergyDetailBindingNavigator)).BeginInit();
            this.tbl_AllergyDetailBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_AllergyDetailDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // noteLabel
            // 
            noteLabel.AutoSize = true;
            noteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            noteLabel.Location = new System.Drawing.Point(55, 69);
            noteLabel.Name = "noteLabel";
            noteLabel.Size = new System.Drawing.Size(44, 13);
            noteLabel.TabIndex = 3;
            noteLabel.Text = "Notes:";
            // 
            // foodLabel
            // 
            foodLabel.AutoSize = true;
            foodLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            foodLabel.Location = new System.Drawing.Point(53, 119);
            foodLabel.Name = "foodLabel";
            foodLabel.Size = new System.Drawing.Size(39, 13);
            foodLabel.TabIndex = 5;
            foodLabel.Text = "Food:";
            // 
            // drugLabel
            // 
            drugLabel.AutoSize = true;
            drugLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            drugLabel.Location = new System.Drawing.Point(56, 174);
            drugLabel.Name = "drugLabel";
            drugLabel.Size = new System.Drawing.Size(38, 13);
            drugLabel.TabIndex = 7;
            drugLabel.Text = "Drug:";
            // 
            // iDLabel
            // 
            iDLabel.AutoSize = true;
            iDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            iDLabel.Location = new System.Drawing.Point(31, 220);
            iDLabel.Name = "iDLabel";
            iDLabel.Size = new System.Drawing.Size(66, 13);
            iDLabel.TabIndex = 9;
            iDLabel.Text = "Allergy ID:";
            // 
            // rIDLabel
            // 
            rIDLabel.AutoSize = true;
            rIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            rIDLabel.Location = new System.Drawing.Point(21, 246);
            rIDLabel.Name = "rIDLabel";
            rIDLabel.Size = new System.Drawing.Size(78, 13);
            rIDLabel.TabIndex = 11;
            rIDLabel.Text = "Resident ID:";
            // 
            // databaseDataSet5
            // 
            this.databaseDataSet5.DataSetName = "DatabaseDataSet5";
            this.databaseDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_AllergyDetailBindingSource
            // 
            this.tbl_AllergyDetailBindingSource.DataMember = "tbl_AllergyDetail";
            this.tbl_AllergyDetailBindingSource.DataSource = this.databaseDataSet5;
            // 
            // tbl_AllergyDetailTableAdapter
            // 
            this.tbl_AllergyDetailTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbl_AllergyDetailTableAdapter = this.tbl_AllergyDetailTableAdapter;
            this.tableAdapterManager.UpdateOrder = OAHMS1.DatabaseDataSet5TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tbl_AllergyDetailBindingNavigator
            // 
            this.tbl_AllergyDetailBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_AllergyDetailBindingNavigator.BindingSource = this.tbl_AllergyDetailBindingSource;
            this.tbl_AllergyDetailBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_AllergyDetailBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_AllergyDetailBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_AllergyDetailBindingNavigatorSaveItem});
            this.tbl_AllergyDetailBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tbl_AllergyDetailBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_AllergyDetailBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_AllergyDetailBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_AllergyDetailBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_AllergyDetailBindingNavigator.Name = "tbl_AllergyDetailBindingNavigator";
            this.tbl_AllergyDetailBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_AllergyDetailBindingNavigator.Size = new System.Drawing.Size(789, 25);
            this.tbl_AllergyDetailBindingNavigator.TabIndex = 0;
            this.tbl_AllergyDetailBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_AllergyDetailBindingNavigatorSaveItem
            // 
            this.tbl_AllergyDetailBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbl_AllergyDetailBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_AllergyDetailBindingNavigatorSaveItem.Image")));
            this.tbl_AllergyDetailBindingNavigatorSaveItem.Name = "tbl_AllergyDetailBindingNavigatorSaveItem";
            this.tbl_AllergyDetailBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tbl_AllergyDetailBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_AllergyDetailBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_AllergyDetailBindingNavigatorSaveItem_Click);
            // 
            // noteTextBox
            // 
            this.noteTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_AllergyDetailBindingSource, "Note", true));
            this.noteTextBox.Location = new System.Drawing.Point(104, 66);
            this.noteTextBox.Multiline = true;
            this.noteTextBox.Name = "noteTextBox";
            this.noteTextBox.Size = new System.Drawing.Size(140, 44);
            this.noteTextBox.TabIndex = 4;
            // 
            // foodTextBox
            // 
            this.foodTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_AllergyDetailBindingSource, "Food", true));
            this.foodTextBox.Location = new System.Drawing.Point(105, 116);
            this.foodTextBox.Multiline = true;
            this.foodTextBox.Name = "foodTextBox";
            this.foodTextBox.Size = new System.Drawing.Size(139, 49);
            this.foodTextBox.TabIndex = 6;
            // 
            // drugTextBox
            // 
            this.drugTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_AllergyDetailBindingSource, "Drug", true));
            this.drugTextBox.Location = new System.Drawing.Point(106, 171);
            this.drugTextBox.Multiline = true;
            this.drugTextBox.Name = "drugTextBox";
            this.drugTextBox.Size = new System.Drawing.Size(138, 40);
            this.drugTextBox.TabIndex = 8;
            // 
            // iDTextBox
            // 
            this.iDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_AllergyDetailBindingSource, "ID", true));
            this.iDTextBox.Location = new System.Drawing.Point(112, 217);
            this.iDTextBox.Name = "iDTextBox";
            this.iDTextBox.Size = new System.Drawing.Size(43, 20);
            this.iDTextBox.TabIndex = 10;
            // 
            // rIDTextBox
            // 
            this.rIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_AllergyDetailBindingSource, "RID", true));
            this.rIDTextBox.Location = new System.Drawing.Point(112, 243);
            this.rIDTextBox.Name = "rIDTextBox";
            this.rIDTextBox.Size = new System.Drawing.Size(43, 20);
            this.rIDTextBox.TabIndex = 12;
            // 
            // tbl_AllergyDetailDataGridView
            // 
            this.tbl_AllergyDetailDataGridView.AutoGenerateColumns = false;
            this.tbl_AllergyDetailDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_AllergyDetailDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.tbl_AllergyDetailDataGridView.DataSource = this.tbl_AllergyDetailBindingSource;
            this.tbl_AllergyDetailDataGridView.Location = new System.Drawing.Point(250, 66);
            this.tbl_AllergyDetailDataGridView.Name = "tbl_AllergyDetailDataGridView";
            this.tbl_AllergyDetailDataGridView.Size = new System.Drawing.Size(539, 300);
            this.tbl_AllergyDetailDataGridView.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 314);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Add New Record";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(114, 314);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(51, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(171, 314);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 16;
            this.button3.Text = "Remove";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(9, 343);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(236, 23);
            this.button4.TabIndex = 17;
            this.button4.Text = "Clear Fields";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Note";
            this.dataGridViewTextBoxColumn2.HeaderText = "Notes";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Food";
            this.dataGridViewTextBoxColumn3.HeaderText = "Food";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Drug";
            this.dataGridViewTextBoxColumn4.HeaderText = "Drug";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn5.HeaderText = "Allergy ID";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "RID";
            this.dataGridViewTextBoxColumn6.HeaderText = "Resident ID";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // Allergy_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 395);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbl_AllergyDetailDataGridView);
            this.Controls.Add(noteLabel);
            this.Controls.Add(this.noteTextBox);
            this.Controls.Add(foodLabel);
            this.Controls.Add(this.foodTextBox);
            this.Controls.Add(drugLabel);
            this.Controls.Add(this.drugTextBox);
            this.Controls.Add(iDLabel);
            this.Controls.Add(this.iDTextBox);
            this.Controls.Add(rIDLabel);
            this.Controls.Add(this.rIDTextBox);
            this.Controls.Add(this.tbl_AllergyDetailBindingNavigator);
            this.Name = "Allergy_Details";
            this.Text = "Allergy_Details";
            this.Load += new System.EventHandler(this.Allergy_Details_Load);
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_AllergyDetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_AllergyDetailBindingNavigator)).EndInit();
            this.tbl_AllergyDetailBindingNavigator.ResumeLayout(false);
            this.tbl_AllergyDetailBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_AllergyDetailDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DatabaseDataSet5 databaseDataSet5;
        private System.Windows.Forms.BindingSource tbl_AllergyDetailBindingSource;
        private DatabaseDataSet5TableAdapters.tbl_AllergyDetailTableAdapter tbl_AllergyDetailTableAdapter;
        private DatabaseDataSet5TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tbl_AllergyDetailBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_AllergyDetailBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox noteTextBox;
        private System.Windows.Forms.TextBox foodTextBox;
        private System.Windows.Forms.TextBox drugTextBox;
        private System.Windows.Forms.TextBox iDTextBox;
        private System.Windows.Forms.TextBox rIDTextBox;
        private System.Windows.Forms.DataGridView tbl_AllergyDetailDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}