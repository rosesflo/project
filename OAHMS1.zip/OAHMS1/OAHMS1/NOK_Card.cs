﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class NOK_Card : Form
    {
        public NOK_Card()
        {
            InitializeComponent();
        }

        private void tbl_NOKBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_NOKBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet13);

        }

        private void NOK_Card_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet13.tbl_NOK' table. You can move, or remove it, as needed.
            this.tbl_NOKTableAdapter.Fill(this.databaseDataSet13.tbl_NOK);

        }
    }
}
