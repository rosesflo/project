﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Allergy_Card : Form
    {
        public Allergy_Card()
        {
            InitializeComponent();
        }

        private void tbl_AllergyBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_AllergyBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet4);

        }

        private void Allergy_Card_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet4.tbl_Allergy' table. You can move, or remove it, as needed.
            this.tbl_AllergyTableAdapter.Fill(this.databaseDataSet4.tbl_Allergy);

        }
    }
}
