﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Condition_Details : Form
    {
        public Condition_Details()
        {
            InitializeComponent();
        }

        private void tbl_ConDetailsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_ConDetailsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet10);

        }

        private void Condition_Details_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet10.tbl_ConDetails' table. You can move, or remove it, as needed.
            this.tbl_ConDetailsTableAdapter.Fill(this.databaseDataSet10.tbl_ConDetails);

        }
    }
}
