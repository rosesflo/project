﻿namespace OAHMS1
{
    partial class frmMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainMenu));
            this.SlidingPanel = new System.Windows.Forms.Panel();
            this.btnCards = new System.Windows.Forms.Button();
            this.SlidingPanel_Toggle_btn = new System.Windows.Forms.Button();
            this.btnResident = new System.Windows.Forms.Button();
            this.btnMedical = new System.Windows.Forms.Button();
            this.btnInquiry = new System.Windows.Forms.Button();
            this.btnEmployee = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.Sliding_Panel_Timer = new System.Windows.Forms.Timer(this.components);
            this.ContentPanel = new System.Windows.Forms.Panel();
            this.SlidingPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // SlidingPanel
            // 
            this.SlidingPanel.Controls.Add(this.btnCards);
            this.SlidingPanel.Controls.Add(this.SlidingPanel_Toggle_btn);
            this.SlidingPanel.Controls.Add(this.btnResident);
            this.SlidingPanel.Controls.Add(this.btnMedical);
            this.SlidingPanel.Controls.Add(this.btnInquiry);
            this.SlidingPanel.Controls.Add(this.btnEmployee);
            this.SlidingPanel.Controls.Add(this.btnReports);
            this.SlidingPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.SlidingPanel.Location = new System.Drawing.Point(0, 0);
            this.SlidingPanel.Name = "SlidingPanel";
            this.SlidingPanel.Size = new System.Drawing.Size(300, 394);
            this.SlidingPanel.TabIndex = 8;
            // 
            // btnCards
            // 
            this.btnCards.BackColor = System.Drawing.Color.Transparent;
            this.btnCards.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCards.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCards.Image = global::OAHMS1.Properties.Resources.cards;
            this.btnCards.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCards.Location = new System.Drawing.Point(0, 192);
            this.btnCards.Name = "btnCards";
            this.btnCards.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnCards.Size = new System.Drawing.Size(300, 51);
            this.btnCards.TabIndex = 7;
            this.btnCards.Text = "Cards";
            this.btnCards.UseVisualStyleBackColor = false;
            // 
            // SlidingPanel_Toggle_btn
            // 
            this.SlidingPanel_Toggle_btn.BackColor = System.Drawing.Color.Transparent;
            this.SlidingPanel_Toggle_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SlidingPanel_Toggle_btn.Image = global::OAHMS1.Properties.Resources.leftArrow1;
            this.SlidingPanel_Toggle_btn.Location = new System.Drawing.Point(0, 0);
            this.SlidingPanel_Toggle_btn.Name = "SlidingPanel_Toggle_btn";
            this.SlidingPanel_Toggle_btn.Size = new System.Drawing.Size(300, 51);
            this.SlidingPanel_Toggle_btn.TabIndex = 6;
            this.SlidingPanel_Toggle_btn.UseVisualStyleBackColor = false;
            this.SlidingPanel_Toggle_btn.Click += new System.EventHandler(this.SlidingPanel_Toggle_btn_Click);
            // 
            // btnResident
            // 
            this.btnResident.BackColor = System.Drawing.Color.Transparent;
            this.btnResident.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResident.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResident.Image = global::OAHMS1.Properties.Resources.resident;
            this.btnResident.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnResident.Location = new System.Drawing.Point(0, 50);
            this.btnResident.Name = "btnResident";
            this.btnResident.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnResident.Size = new System.Drawing.Size(300, 48);
            this.btnResident.TabIndex = 0;
            this.btnResident.Text = "Resident Records";
            this.btnResident.UseVisualStyleBackColor = false;
            this.btnResident.Click += new System.EventHandler(this.btnResident_Click);
            // 
            // btnMedical
            // 
            this.btnMedical.BackColor = System.Drawing.Color.Transparent;
            this.btnMedical.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedical.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedical.Image = global::OAHMS1.Properties.Resources.medRecords;
            this.btnMedical.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMedical.Location = new System.Drawing.Point(0, 95);
            this.btnMedical.Name = "btnMedical";
            this.btnMedical.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnMedical.Size = new System.Drawing.Size(300, 51);
            this.btnMedical.TabIndex = 2;
            this.btnMedical.Text = "Medical Records";
            this.btnMedical.UseVisualStyleBackColor = false;
            // 
            // btnInquiry
            // 
            this.btnInquiry.BackColor = System.Drawing.Color.Transparent;
            this.btnInquiry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInquiry.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInquiry.Image = global::OAHMS1.Properties.Resources.inquiry;
            this.btnInquiry.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInquiry.Location = new System.Drawing.Point(0, 294);
            this.btnInquiry.Name = "btnInquiry";
            this.btnInquiry.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnInquiry.Size = new System.Drawing.Size(300, 51);
            this.btnInquiry.TabIndex = 5;
            this.btnInquiry.Text = "Inquiry";
            this.btnInquiry.UseVisualStyleBackColor = false;
            // 
            // btnEmployee
            // 
            this.btnEmployee.BackColor = System.Drawing.Color.Transparent;
            this.btnEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployee.Image = global::OAHMS1.Properties.Resources.employee;
            this.btnEmployee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEmployee.Location = new System.Drawing.Point(0, 142);
            this.btnEmployee.Name = "btnEmployee";
            this.btnEmployee.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnEmployee.Size = new System.Drawing.Size(300, 51);
            this.btnEmployee.TabIndex = 1;
            this.btnEmployee.Text = "Employee Records";
            this.btnEmployee.UseVisualStyleBackColor = false;
            // 
            // btnReports
            // 
            this.btnReports.BackColor = System.Drawing.Color.Transparent;
            this.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReports.Image = global::OAHMS1.Properties.Resources.reports;
            this.btnReports.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReports.Location = new System.Drawing.Point(0, 243);
            this.btnReports.Name = "btnReports";
            this.btnReports.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnReports.Size = new System.Drawing.Size(300, 51);
            this.btnReports.TabIndex = 4;
            this.btnReports.Text = "Reports";
            this.btnReports.UseVisualStyleBackColor = false;
            // 
            // Sliding_Panel_Timer
            // 
            this.Sliding_Panel_Timer.Interval = 10;
            this.Sliding_Panel_Timer.Tick += new System.EventHandler(this.Sliding_Panel_Timer_Tick);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.ContentPanel.Location = new System.Drawing.Point(296, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.Size = new System.Drawing.Size(549, 394);
            this.ContentPanel.TabIndex = 9;
            // 
            // frmMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.ClientSize = new System.Drawing.Size(845, 394);
            this.Controls.Add(this.ContentPanel);
            this.Controls.Add(this.SlidingPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMainMenu";
            this.Text = "Main Menu";
            this.SlidingPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnResident;
        private System.Windows.Forms.Button btnEmployee;
        private System.Windows.Forms.Button btnMedical;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnInquiry;
        private System.Windows.Forms.Panel SlidingPanel;
        private System.Windows.Forms.Button SlidingPanel_Toggle_btn;
        private System.Windows.Forms.Button btnCards;
        private System.Windows.Forms.Timer Sliding_Panel_Timer;
        private System.Windows.Forms.Panel ContentPanel;
    }
}