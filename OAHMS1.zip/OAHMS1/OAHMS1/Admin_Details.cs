﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Admin_Details : Form
    {
        public Admin_Details()
        {
            InitializeComponent();
        }

        private void tbl_AdminDetailsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_AdminDetailsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet3);

        }

        private void Admin_Details_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet3.tbl_AdminDetails' table. You can move, or remove it, as needed.
            this.tbl_AdminDetailsTableAdapter.Fill(this.databaseDataSet3.tbl_AdminDetails);

        }
    }
}
