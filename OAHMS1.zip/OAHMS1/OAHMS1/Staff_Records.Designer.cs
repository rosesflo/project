﻿namespace OAHMS1
{
    partial class Staff_Records
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label homeIDLabel;
            System.Windows.Forms.Label volunteerLabel;
            System.Windows.Forms.Label rateLabel;
            System.Windows.Forms.Label salaryLabel;
            System.Windows.Forms.Label notesLabel;
            System.Windows.Forms.Label staffIDLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Staff_Records));
            this.databaseDataSet20 = new OAHMS1.DatabaseDataSet20();
            this.tbl_StaffRecordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_StaffRecordsTableAdapter = new OAHMS1.DatabaseDataSet20TableAdapters.tbl_StaffRecordsTableAdapter();
            this.tableAdapterManager = new OAHMS1.DatabaseDataSet20TableAdapters.TableAdapterManager();
            this.tbl_StaffRecordsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_StaffRecordsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.homeIDTextBox = new System.Windows.Forms.TextBox();
            this.volunteerTextBox = new System.Windows.Forms.TextBox();
            this.rateTextBox = new System.Windows.Forms.TextBox();
            this.salaryTextBox = new System.Windows.Forms.TextBox();
            this.notesTextBox = new System.Windows.Forms.TextBox();
            this.staffIDTextBox = new System.Windows.Forms.TextBox();
            this.tbl_StaffRecordsDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            homeIDLabel = new System.Windows.Forms.Label();
            volunteerLabel = new System.Windows.Forms.Label();
            rateLabel = new System.Windows.Forms.Label();
            salaryLabel = new System.Windows.Forms.Label();
            notesLabel = new System.Windows.Forms.Label();
            staffIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StaffRecordsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StaffRecordsBindingNavigator)).BeginInit();
            this.tbl_StaffRecordsBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StaffRecordsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // homeIDLabel
            // 
            homeIDLabel.AutoSize = true;
            homeIDLabel.Location = new System.Drawing.Point(48, 64);
            homeIDLabel.Name = "homeIDLabel";
            homeIDLabel.Size = new System.Drawing.Size(52, 13);
            homeIDLabel.TabIndex = 3;
            homeIDLabel.Text = "Home ID:";
            // 
            // volunteerLabel
            // 
            volunteerLabel.AutoSize = true;
            volunteerLabel.Location = new System.Drawing.Point(48, 90);
            volunteerLabel.Name = "volunteerLabel";
            volunteerLabel.Size = new System.Drawing.Size(55, 13);
            volunteerLabel.TabIndex = 5;
            volunteerLabel.Text = "Volunteer:";
            // 
            // rateLabel
            // 
            rateLabel.AutoSize = true;
            rateLabel.Location = new System.Drawing.Point(48, 116);
            rateLabel.Name = "rateLabel";
            rateLabel.Size = new System.Drawing.Size(33, 13);
            rateLabel.TabIndex = 7;
            rateLabel.Text = "Rate:";
            // 
            // salaryLabel
            // 
            salaryLabel.AutoSize = true;
            salaryLabel.Location = new System.Drawing.Point(48, 142);
            salaryLabel.Name = "salaryLabel";
            salaryLabel.Size = new System.Drawing.Size(39, 13);
            salaryLabel.TabIndex = 9;
            salaryLabel.Text = "Salary:";
            // 
            // notesLabel
            // 
            notesLabel.AutoSize = true;
            notesLabel.Location = new System.Drawing.Point(48, 168);
            notesLabel.Name = "notesLabel";
            notesLabel.Size = new System.Drawing.Size(38, 13);
            notesLabel.TabIndex = 11;
            notesLabel.Text = "Notes:";
            // 
            // staffIDLabel
            // 
            staffIDLabel.AutoSize = true;
            staffIDLabel.Location = new System.Drawing.Point(48, 216);
            staffIDLabel.Name = "staffIDLabel";
            staffIDLabel.Size = new System.Drawing.Size(46, 13);
            staffIDLabel.TabIndex = 13;
            staffIDLabel.Text = "Staff ID:";
            // 
            // databaseDataSet20
            // 
            this.databaseDataSet20.DataSetName = "DatabaseDataSet20";
            this.databaseDataSet20.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_StaffRecordsBindingSource
            // 
            this.tbl_StaffRecordsBindingSource.DataMember = "tbl_StaffRecords";
            this.tbl_StaffRecordsBindingSource.DataSource = this.databaseDataSet20;
            // 
            // tbl_StaffRecordsTableAdapter
            // 
            this.tbl_StaffRecordsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbl_StaffRecordsTableAdapter = this.tbl_StaffRecordsTableAdapter;
            this.tableAdapterManager.UpdateOrder = OAHMS1.DatabaseDataSet20TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tbl_StaffRecordsBindingNavigator
            // 
            this.tbl_StaffRecordsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_StaffRecordsBindingNavigator.BindingSource = this.tbl_StaffRecordsBindingSource;
            this.tbl_StaffRecordsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_StaffRecordsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_StaffRecordsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_StaffRecordsBindingNavigatorSaveItem});
            this.tbl_StaffRecordsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tbl_StaffRecordsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_StaffRecordsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_StaffRecordsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_StaffRecordsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_StaffRecordsBindingNavigator.Name = "tbl_StaffRecordsBindingNavigator";
            this.tbl_StaffRecordsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_StaffRecordsBindingNavigator.Size = new System.Drawing.Size(785, 25);
            this.tbl_StaffRecordsBindingNavigator.TabIndex = 0;
            this.tbl_StaffRecordsBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_StaffRecordsBindingNavigatorSaveItem
            // 
            this.tbl_StaffRecordsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbl_StaffRecordsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_StaffRecordsBindingNavigatorSaveItem.Image")));
            this.tbl_StaffRecordsBindingNavigatorSaveItem.Name = "tbl_StaffRecordsBindingNavigatorSaveItem";
            this.tbl_StaffRecordsBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tbl_StaffRecordsBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_StaffRecordsBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_StaffRecordsBindingNavigatorSaveItem_Click);
            // 
            // homeIDTextBox
            // 
            this.homeIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StaffRecordsBindingSource, "HomeID", true));
            this.homeIDTextBox.Location = new System.Drawing.Point(113, 61);
            this.homeIDTextBox.Name = "homeIDTextBox";
            this.homeIDTextBox.Size = new System.Drawing.Size(66, 20);
            this.homeIDTextBox.TabIndex = 4;
            // 
            // volunteerTextBox
            // 
            this.volunteerTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StaffRecordsBindingSource, "Volunteer", true));
            this.volunteerTextBox.Location = new System.Drawing.Point(113, 87);
            this.volunteerTextBox.Name = "volunteerTextBox";
            this.volunteerTextBox.Size = new System.Drawing.Size(66, 20);
            this.volunteerTextBox.TabIndex = 6;
            // 
            // rateTextBox
            // 
            this.rateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StaffRecordsBindingSource, "Rate", true));
            this.rateTextBox.Location = new System.Drawing.Point(113, 113);
            this.rateTextBox.Name = "rateTextBox";
            this.rateTextBox.Size = new System.Drawing.Size(100, 20);
            this.rateTextBox.TabIndex = 8;
            // 
            // salaryTextBox
            // 
            this.salaryTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StaffRecordsBindingSource, "Salary", true));
            this.salaryTextBox.Location = new System.Drawing.Point(113, 139);
            this.salaryTextBox.Name = "salaryTextBox";
            this.salaryTextBox.Size = new System.Drawing.Size(100, 20);
            this.salaryTextBox.TabIndex = 10;
            // 
            // notesTextBox
            // 
            this.notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StaffRecordsBindingSource, "Notes", true));
            this.notesTextBox.Location = new System.Drawing.Point(113, 165);
            this.notesTextBox.Multiline = true;
            this.notesTextBox.Name = "notesTextBox";
            this.notesTextBox.Size = new System.Drawing.Size(100, 42);
            this.notesTextBox.TabIndex = 12;
            // 
            // staffIDTextBox
            // 
            this.staffIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StaffRecordsBindingSource, "StaffID", true));
            this.staffIDTextBox.Location = new System.Drawing.Point(113, 213);
            this.staffIDTextBox.Name = "staffIDTextBox";
            this.staffIDTextBox.Size = new System.Drawing.Size(66, 20);
            this.staffIDTextBox.TabIndex = 14;
            // 
            // tbl_StaffRecordsDataGridView
            // 
            this.tbl_StaffRecordsDataGridView.AutoGenerateColumns = false;
            this.tbl_StaffRecordsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_StaffRecordsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.tbl_StaffRecordsDataGridView.DataSource = this.tbl_StaffRecordsBindingSource;
            this.tbl_StaffRecordsDataGridView.Location = new System.Drawing.Point(276, 56);
            this.tbl_StaffRecordsDataGridView.Name = "tbl_StaffRecordsDataGridView";
            this.tbl_StaffRecordsDataGridView.Size = new System.Drawing.Size(497, 309);
            this.tbl_StaffRecordsDataGridView.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(25, 313);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Add New Record";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(136, 313);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(43, 23);
            this.button2.TabIndex = 17;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(185, 313);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 18;
            this.button3.Text = "Remove";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(25, 342);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(235, 23);
            this.button4.TabIndex = 19;
            this.button4.Text = "Clear Fields";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "HomeID";
            this.dataGridViewTextBoxColumn2.HeaderText = "Home ID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Volunteer";
            this.dataGridViewTextBoxColumn3.HeaderText = "Volunteer";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Rate";
            this.dataGridViewTextBoxColumn4.HeaderText = "Rate";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Salary";
            this.dataGridViewTextBoxColumn5.HeaderText = "Salary";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Notes";
            this.dataGridViewTextBoxColumn6.HeaderText = "Notes";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "StaffID";
            this.dataGridViewTextBoxColumn7.HeaderText = "Staff ID";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // Staff_Records
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 391);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbl_StaffRecordsDataGridView);
            this.Controls.Add(homeIDLabel);
            this.Controls.Add(this.homeIDTextBox);
            this.Controls.Add(volunteerLabel);
            this.Controls.Add(this.volunteerTextBox);
            this.Controls.Add(rateLabel);
            this.Controls.Add(this.rateTextBox);
            this.Controls.Add(salaryLabel);
            this.Controls.Add(this.salaryTextBox);
            this.Controls.Add(notesLabel);
            this.Controls.Add(this.notesTextBox);
            this.Controls.Add(staffIDLabel);
            this.Controls.Add(this.staffIDTextBox);
            this.Controls.Add(this.tbl_StaffRecordsBindingNavigator);
            this.Name = "Staff_Records";
            this.Text = "Staff_Records";
            this.Load += new System.EventHandler(this.Staff_Records_Load);
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StaffRecordsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StaffRecordsBindingNavigator)).EndInit();
            this.tbl_StaffRecordsBindingNavigator.ResumeLayout(false);
            this.tbl_StaffRecordsBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StaffRecordsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DatabaseDataSet20 databaseDataSet20;
        private System.Windows.Forms.BindingSource tbl_StaffRecordsBindingSource;
        private DatabaseDataSet20TableAdapters.tbl_StaffRecordsTableAdapter tbl_StaffRecordsTableAdapter;
        private DatabaseDataSet20TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tbl_StaffRecordsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_StaffRecordsBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox homeIDTextBox;
        private System.Windows.Forms.TextBox volunteerTextBox;
        private System.Windows.Forms.TextBox rateTextBox;
        private System.Windows.Forms.TextBox salaryTextBox;
        private System.Windows.Forms.TextBox notesTextBox;
        private System.Windows.Forms.TextBox staffIDTextBox;
        private System.Windows.Forms.DataGridView tbl_StaffRecordsDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}