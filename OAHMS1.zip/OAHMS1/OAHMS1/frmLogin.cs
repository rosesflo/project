﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OAHMS1
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\administrator\Documents\LocalDB\OAHMS1\OAHMS1\Database.mdf;Integrated Security=True;");
       // SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True;");
        SqlCommand cmd;
        SqlDataReader dr;

        private String getUserId()
        {
            //fetch UserID data from the database
            con.Open();
            String syntax = "Select UserID from tbl_Users where UserId = '"+txtUserId.Text+"'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            String temp = dr[0].ToString();
            con.Close();
            return temp;
        }

        private String getPassword()
        {
            //fetch Password data from the database
            con.Open();
            String syntax = "Select Password from tbl_Users where UserId = '"+txtUserId.Text+"'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();

            String temp = "";
            if (dr.HasRows)

            {
                temp = dr[0].ToString();
            }
            
            con.Close();
            return temp;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            String UPassword = getPassword(), password;
            //name = txtUserId.Text;//
            password = txtPassword.Text;

            if (password.Equals(UPassword))
            {
                MessageBox.Show("Login successful");

                this.Hide();
                //frmMainMenu mn = new frmMainMenu();
                //mn.Show();
                Activity_Card ac = new Activity_Card();
                ac.Show();
            }

            else
            {
                MessageBox.Show("Login failed...please try again");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}