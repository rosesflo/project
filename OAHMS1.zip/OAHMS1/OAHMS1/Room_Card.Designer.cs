﻿namespace OAHMS1
{
    partial class Room_Card
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Room_Card));
            System.Windows.Forms.Label roomNoLabel;
            System.Windows.Forms.Label availableLabel;
            this.databaseDataSet15 = new OAHMS1.DatabaseDataSet15();
            this.tbl_RoomBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_RoomTableAdapter = new OAHMS1.DatabaseDataSet15TableAdapters.tbl_RoomTableAdapter();
            this.tableAdapterManager = new OAHMS1.DatabaseDataSet15TableAdapters.TableAdapterManager();
            this.tbl_RoomBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.tbl_RoomBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.roomNoTextBox = new System.Windows.Forms.TextBox();
            this.availableTextBox = new System.Windows.Forms.TextBox();
            this.tbl_RoomDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            roomNoLabel = new System.Windows.Forms.Label();
            availableLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_RoomBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_RoomBindingNavigator)).BeginInit();
            this.tbl_RoomBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_RoomDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // databaseDataSet15
            // 
            this.databaseDataSet15.DataSetName = "DatabaseDataSet15";
            this.databaseDataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_RoomBindingSource
            // 
            this.tbl_RoomBindingSource.DataMember = "tbl_Room";
            this.tbl_RoomBindingSource.DataSource = this.databaseDataSet15;
            // 
            // tbl_RoomTableAdapter
            // 
            this.tbl_RoomTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbl_RoomTableAdapter = this.tbl_RoomTableAdapter;
            this.tableAdapterManager.UpdateOrder = OAHMS1.DatabaseDataSet15TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tbl_RoomBindingNavigator
            // 
            this.tbl_RoomBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_RoomBindingNavigator.BindingSource = this.tbl_RoomBindingSource;
            this.tbl_RoomBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_RoomBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_RoomBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_RoomBindingNavigatorSaveItem});
            this.tbl_RoomBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tbl_RoomBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_RoomBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_RoomBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_RoomBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_RoomBindingNavigator.Name = "tbl_RoomBindingNavigator";
            this.tbl_RoomBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_RoomBindingNavigator.Size = new System.Drawing.Size(540, 25);
            this.tbl_RoomBindingNavigator.TabIndex = 0;
            this.tbl_RoomBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // tbl_RoomBindingNavigatorSaveItem
            // 
            this.tbl_RoomBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbl_RoomBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_RoomBindingNavigatorSaveItem.Image")));
            this.tbl_RoomBindingNavigatorSaveItem.Name = "tbl_RoomBindingNavigatorSaveItem";
            this.tbl_RoomBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.tbl_RoomBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_RoomBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_RoomBindingNavigatorSaveItem_Click);
            // 
            // roomNoLabel
            // 
            roomNoLabel.AutoSize = true;
            roomNoLabel.Location = new System.Drawing.Point(17, 59);
            roomNoLabel.Name = "roomNoLabel";
            roomNoLabel.Size = new System.Drawing.Size(55, 13);
            roomNoLabel.TabIndex = 1;
            roomNoLabel.Text = "Room No:";
            // 
            // roomNoTextBox
            // 
            this.roomNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_RoomBindingSource, "RoomNo", true));
            this.roomNoTextBox.Location = new System.Drawing.Point(78, 56);
            this.roomNoTextBox.Name = "roomNoTextBox";
            this.roomNoTextBox.Size = new System.Drawing.Size(100, 20);
            this.roomNoTextBox.TabIndex = 2;
            // 
            // availableLabel
            // 
            availableLabel.AutoSize = true;
            availableLabel.Location = new System.Drawing.Point(17, 85);
            availableLabel.Name = "availableLabel";
            availableLabel.Size = new System.Drawing.Size(53, 13);
            availableLabel.TabIndex = 3;
            availableLabel.Text = "Available:";
            // 
            // availableTextBox
            // 
            this.availableTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_RoomBindingSource, "Available", true));
            this.availableTextBox.Location = new System.Drawing.Point(78, 82);
            this.availableTextBox.Name = "availableTextBox";
            this.availableTextBox.Size = new System.Drawing.Size(100, 20);
            this.availableTextBox.TabIndex = 4;
            // 
            // tbl_RoomDataGridView
            // 
            this.tbl_RoomDataGridView.AutoGenerateColumns = false;
            this.tbl_RoomDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_RoomDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.tbl_RoomDataGridView.DataSource = this.tbl_RoomBindingSource;
            this.tbl_RoomDataGridView.Location = new System.Drawing.Point(277, 56);
            this.tbl_RoomDataGridView.Name = "tbl_RoomDataGridView";
            this.tbl_RoomDataGridView.Size = new System.Drawing.Size(241, 176);
            this.tbl_RoomDataGridView.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(20, 171);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Add New Record";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(124, 171);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(54, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(184, 171);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 8;
            this.button3.Text = "Remove";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(20, 209);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(239, 23);
            this.button4.TabIndex = 9;
            this.button4.Text = "Clear Fields";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "RoomNo";
            this.dataGridViewTextBoxColumn1.HeaderText = "Room No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Available";
            this.dataGridViewTextBoxColumn2.HeaderText = "Available";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // Room_Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 265);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbl_RoomDataGridView);
            this.Controls.Add(roomNoLabel);
            this.Controls.Add(this.roomNoTextBox);
            this.Controls.Add(availableLabel);
            this.Controls.Add(this.availableTextBox);
            this.Controls.Add(this.tbl_RoomBindingNavigator);
            this.Name = "Room_Card";
            this.Text = "Room_Card";
            this.Load += new System.EventHandler(this.Room_Card_Load);
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_RoomBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_RoomBindingNavigator)).EndInit();
            this.tbl_RoomBindingNavigator.ResumeLayout(false);
            this.tbl_RoomBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_RoomDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DatabaseDataSet15 databaseDataSet15;
        private System.Windows.Forms.BindingSource tbl_RoomBindingSource;
        private DatabaseDataSet15TableAdapters.tbl_RoomTableAdapter tbl_RoomTableAdapter;
        private DatabaseDataSet15TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tbl_RoomBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_RoomBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox roomNoTextBox;
        private System.Windows.Forms.TextBox availableTextBox;
        private System.Windows.Forms.DataGridView tbl_RoomDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}