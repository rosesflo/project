﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Medical_Records : Form
    {
        public Medical_Records()
        {
            InitializeComponent();
        }

        private void tbl_MedicalRecordsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_MedicalRecordsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet12);

        }

        private void Medical_Records_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet12.tbl_MedicalRecords' table. You can move, or remove it, as needed.
            this.tbl_MedicalRecordsTableAdapter.Fill(this.databaseDataSet12.tbl_MedicalRecords);

        }
    }
}
