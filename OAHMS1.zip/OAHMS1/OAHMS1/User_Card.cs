﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class User_Card : Form
    {
        public User_Card()
        {
            InitializeComponent();
        }

        private void tbl_UsersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_UsersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet7);

        }

        private void User_Card_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet7.tbl_Users' table. You can move, or remove it, as needed.
            this.tbl_UsersTableAdapter.Fill(this.databaseDataSet7.tbl_Users);

        }
    }
}
