﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Room_Detail : Form
    {
        public Room_Detail()
        {
            InitializeComponent();
        }

        private void tbl_RoomDetailBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_RoomDetailBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet16);

        }

        private void Room_Detail_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet16.tbl_RoomDetail' table. You can move, or remove it, as needed.
            this.tbl_RoomDetailTableAdapter.Fill(this.databaseDataSet16.tbl_RoomDetail);

        }
    }
}
