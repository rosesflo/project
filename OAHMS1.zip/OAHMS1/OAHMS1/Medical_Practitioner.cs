﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Medical_Practitioner : Form
    {
        public Medical_Practitioner()
        {
            InitializeComponent();
        }

        private void tbl_MedicalPractitionerBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_MedicalPractitionerBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet11);

        }

        private void Medical_Practitioner_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet11.tbl_MedicalPractitioner' table. You can move, or remove it, as needed.
            this.tbl_MedicalPractitionerTableAdapter.Fill(this.databaseDataSet11.tbl_MedicalPractitioner);

        }
    }
}
