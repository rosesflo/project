﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class frmMainMenu : Form
    {
        public frmMainMenu()
        {
            InitializeComponent();
            //when the application opens these are the defaults
            //the sliding panel will be opened
            IsSlidingPanelExpanded = true;
            expandSlidingPanelGui();
        }

       
        //expandSlidingPanel function
        public void expandSlidingPanelGui()
        {
            //Gui adjustments for expanding the sliding panel

            btnResident.Text = "Resident Records";
            btnMedical.Text = "Medical Records";
            btnEmployee.Text = "Employee Records";
            btnCards.Text = "Cards";
            btnReports.Text = "Reports";
            btnInquiry.Text = "Inquiry";
            SlidingPanel_Toggle_btn.Image = Properties.Resources.leftArrow1;

            //hide images
            btnResident.Image = null;
            btnMedical.Image = null;
            btnEmployee.Image = null;
            btnCards.Image = null;
            btnReports.Image = null;
            btnInquiry.Image = null;
        }

        //retractSlidingPanel function
        public void retractSlidingPanelGui()
        {
            //Gui adjustments for retracting the sliding panel

            btnResident.Text = "";
            btnMedical.Text = "";
            btnEmployee.Text = "";
            btnCards.Text = "";
            btnReports.Text = "";
            btnInquiry.Text = "";
            SlidingPanel_Toggle_btn.Image = Properties.Resources.rightArrow;

            //hide images
            btnResident.Image = Properties.Resources.resident;
            btnMedical.Image = Properties.Resources.medRecords;
            btnEmployee.Image = Properties.Resources.employee;
            btnCards.Image = Properties.Resources.cards;
            btnReports.Image = Properties.Resources.reports;
            btnInquiry.Image = Properties.Resources.inquiry;
        }
        //sliding panel code starts here to expand and retract
        //variables are constant in terms of the expanding and retracting of the panel

        bool IsSlidingPanelExpanded;
        const int MaxSlideWidth = 300;
        const int MinSlideWidth = 100;

        private void SlidingPanel_Toggle_btn_Click(object sender, EventArgs e)
        {
            if (IsSlidingPanelExpanded)
            {
                 retractSlidingPanelGui();//call function
            }

            Sliding_Panel_Timer.Start();

        }

        private void Sliding_Panel_Timer_Tick(object sender, EventArgs e)
        {
            if (IsSlidingPanelExpanded)
            {
                //retract panel
                SlidingPanel.Width -= 30;
                if (SlidingPanel.Width <= MinSlideWidth)
                {
                    //stop retract
                    IsSlidingPanelExpanded = false;
                    Sliding_Panel_Timer.Stop();

                    this.Refresh();
                }
            }
            else
            {
                //expand panel
                SlidingPanel.Width += 30;

                //if (IsSlidingPanelExpanded)
                //{
                    
                    if (SlidingPanel.Width >= MaxSlideWidth)
                    {
                        //stop expanding
                        IsSlidingPanelExpanded = true;
                        Sliding_Panel_Timer.Stop();

                        expandSlidingPanelGui();//call function
                        this.Refresh();
                    }

                }
            }

        private void btnResident_Click(object sender, EventArgs e)
        {
            if(! ContentPanel.Controls.Contains(ResidentUserControl1.Instance))
            {
                ContentPanel.Controls.Add(ResidentUserControl1.Instance);
                ResidentUserControl1.Instance.Dock = DockStyle.Fill;
                ResidentUserControl1.Instance.BringToFront();
            }
            else
            {
                ResidentUserControl1.Instance.BringToFront();
            }
        }
    }
    }

    

