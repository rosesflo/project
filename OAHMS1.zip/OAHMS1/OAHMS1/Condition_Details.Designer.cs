﻿namespace OAHMS1
{
    partial class Condition_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label diabetesLabel;
            System.Windows.Forms.Label hypertensionLabel;
            System.Windows.Forms.Label glaucomaLabel;
            System.Windows.Forms.Label dementiaLabel;
            System.Windows.Forms.Label cIDLabel;
            System.Windows.Forms.Label rIDLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Condition_Details));
            this.databaseDataSet10 = new OAHMS1.DatabaseDataSet10();
            this.tbl_ConDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_ConDetailsTableAdapter = new OAHMS1.DatabaseDataSet10TableAdapters.tbl_ConDetailsTableAdapter();
            this.tableAdapterManager = new OAHMS1.DatabaseDataSet10TableAdapters.TableAdapterManager();
            this.tbl_ConDetailsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_ConDetailsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.diabetesTextBox = new System.Windows.Forms.TextBox();
            this.hypertensionTextBox = new System.Windows.Forms.TextBox();
            this.glaucomaTextBox = new System.Windows.Forms.TextBox();
            this.dementiaTextBox = new System.Windows.Forms.TextBox();
            this.cIDTextBox = new System.Windows.Forms.TextBox();
            this.rIDTextBox = new System.Windows.Forms.TextBox();
            this.tbl_ConDetailsDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            diabetesLabel = new System.Windows.Forms.Label();
            hypertensionLabel = new System.Windows.Forms.Label();
            glaucomaLabel = new System.Windows.Forms.Label();
            dementiaLabel = new System.Windows.Forms.Label();
            cIDLabel = new System.Windows.Forms.Label();
            rIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ConDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ConDetailsBindingNavigator)).BeginInit();
            this.tbl_ConDetailsBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ConDetailsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // diabetesLabel
            // 
            diabetesLabel.AutoSize = true;
            diabetesLabel.Location = new System.Drawing.Point(29, 109);
            diabetesLabel.Name = "diabetesLabel";
            diabetesLabel.Size = new System.Drawing.Size(52, 13);
            diabetesLabel.TabIndex = 3;
            diabetesLabel.Text = "Diabetes:";
            // 
            // hypertensionLabel
            // 
            hypertensionLabel.AutoSize = true;
            hypertensionLabel.Location = new System.Drawing.Point(29, 135);
            hypertensionLabel.Name = "hypertensionLabel";
            hypertensionLabel.Size = new System.Drawing.Size(72, 13);
            hypertensionLabel.TabIndex = 5;
            hypertensionLabel.Text = "Hypertension:";
            // 
            // glaucomaLabel
            // 
            glaucomaLabel.AutoSize = true;
            glaucomaLabel.Location = new System.Drawing.Point(29, 161);
            glaucomaLabel.Name = "glaucomaLabel";
            glaucomaLabel.Size = new System.Drawing.Size(58, 13);
            glaucomaLabel.TabIndex = 7;
            glaucomaLabel.Text = "Glaucoma:";
            // 
            // dementiaLabel
            // 
            dementiaLabel.AutoSize = true;
            dementiaLabel.Location = new System.Drawing.Point(29, 216);
            dementiaLabel.Name = "dementiaLabel";
            dementiaLabel.Size = new System.Drawing.Size(55, 13);
            dementiaLabel.TabIndex = 9;
            dementiaLabel.Text = "Dementia:";
            // 
            // cIDLabel
            // 
            cIDLabel.AutoSize = true;
            cIDLabel.Location = new System.Drawing.Point(29, 57);
            cIDLabel.Name = "cIDLabel";
            cIDLabel.Size = new System.Drawing.Size(68, 13);
            cIDLabel.TabIndex = 11;
            cIDLabel.Text = "Condition ID:";
            // 
            // rIDLabel
            // 
            rIDLabel.AutoSize = true;
            rIDLabel.Location = new System.Drawing.Point(29, 83);
            rIDLabel.Name = "rIDLabel";
            rIDLabel.Size = new System.Drawing.Size(66, 13);
            rIDLabel.TabIndex = 13;
            rIDLabel.Text = "Resident ID:";
            // 
            // databaseDataSet10
            // 
            this.databaseDataSet10.DataSetName = "DatabaseDataSet10";
            this.databaseDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_ConDetailsBindingSource
            // 
            this.tbl_ConDetailsBindingSource.DataMember = "tbl_ConDetails";
            this.tbl_ConDetailsBindingSource.DataSource = this.databaseDataSet10;
            // 
            // tbl_ConDetailsTableAdapter
            // 
            this.tbl_ConDetailsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbl_ConDetailsTableAdapter = this.tbl_ConDetailsTableAdapter;
            this.tableAdapterManager.UpdateOrder = OAHMS1.DatabaseDataSet10TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tbl_ConDetailsBindingNavigator
            // 
            this.tbl_ConDetailsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_ConDetailsBindingNavigator.BindingSource = this.tbl_ConDetailsBindingSource;
            this.tbl_ConDetailsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_ConDetailsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_ConDetailsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_ConDetailsBindingNavigatorSaveItem});
            this.tbl_ConDetailsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tbl_ConDetailsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_ConDetailsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_ConDetailsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_ConDetailsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_ConDetailsBindingNavigator.Name = "tbl_ConDetailsBindingNavigator";
            this.tbl_ConDetailsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_ConDetailsBindingNavigator.Size = new System.Drawing.Size(845, 25);
            this.tbl_ConDetailsBindingNavigator.TabIndex = 0;
            this.tbl_ConDetailsBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_ConDetailsBindingNavigatorSaveItem
            // 
            this.tbl_ConDetailsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbl_ConDetailsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_ConDetailsBindingNavigatorSaveItem.Image")));
            this.tbl_ConDetailsBindingNavigatorSaveItem.Name = "tbl_ConDetailsBindingNavigatorSaveItem";
            this.tbl_ConDetailsBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tbl_ConDetailsBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_ConDetailsBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_ConDetailsBindingNavigatorSaveItem_Click);
            // 
            // diabetesTextBox
            // 
            this.diabetesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_ConDetailsBindingSource, "Diabetes", true));
            this.diabetesTextBox.Location = new System.Drawing.Point(107, 106);
            this.diabetesTextBox.Name = "diabetesTextBox";
            this.diabetesTextBox.Size = new System.Drawing.Size(141, 20);
            this.diabetesTextBox.TabIndex = 4;
            // 
            // hypertensionTextBox
            // 
            this.hypertensionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_ConDetailsBindingSource, "Hypertension", true));
            this.hypertensionTextBox.Location = new System.Drawing.Point(107, 132);
            this.hypertensionTextBox.Name = "hypertensionTextBox";
            this.hypertensionTextBox.Size = new System.Drawing.Size(141, 20);
            this.hypertensionTextBox.TabIndex = 6;
            // 
            // glaucomaTextBox
            // 
            this.glaucomaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_ConDetailsBindingSource, "Glaucoma", true));
            this.glaucomaTextBox.Location = new System.Drawing.Point(107, 158);
            this.glaucomaTextBox.Multiline = true;
            this.glaucomaTextBox.Name = "glaucomaTextBox";
            this.glaucomaTextBox.Size = new System.Drawing.Size(141, 49);
            this.glaucomaTextBox.TabIndex = 8;
            // 
            // dementiaTextBox
            // 
            this.dementiaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_ConDetailsBindingSource, "Dementia", true));
            this.dementiaTextBox.Location = new System.Drawing.Point(107, 213);
            this.dementiaTextBox.Multiline = true;
            this.dementiaTextBox.Name = "dementiaTextBox";
            this.dementiaTextBox.Size = new System.Drawing.Size(141, 44);
            this.dementiaTextBox.TabIndex = 10;
            // 
            // cIDTextBox
            // 
            this.cIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_ConDetailsBindingSource, "CID", true));
            this.cIDTextBox.Location = new System.Drawing.Point(107, 54);
            this.cIDTextBox.Name = "cIDTextBox";
            this.cIDTextBox.Size = new System.Drawing.Size(65, 20);
            this.cIDTextBox.TabIndex = 12;
            // 
            // rIDTextBox
            // 
            this.rIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_ConDetailsBindingSource, "RID", true));
            this.rIDTextBox.Location = new System.Drawing.Point(107, 80);
            this.rIDTextBox.Name = "rIDTextBox";
            this.rIDTextBox.Size = new System.Drawing.Size(65, 20);
            this.rIDTextBox.TabIndex = 14;
            // 
            // tbl_ConDetailsDataGridView
            // 
            this.tbl_ConDetailsDataGridView.AutoGenerateColumns = false;
            this.tbl_ConDetailsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_ConDetailsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.tbl_ConDetailsDataGridView.DataSource = this.tbl_ConDetailsBindingSource;
            this.tbl_ConDetailsDataGridView.Location = new System.Drawing.Point(273, 54);
            this.tbl_ConDetailsDataGridView.Name = "tbl_ConDetailsDataGridView";
            this.tbl_ConDetailsDataGridView.Size = new System.Drawing.Size(560, 283);
            this.tbl_ConDetailsDataGridView.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(24, 285);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Add New Record";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(128, 285);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(56, 23);
            this.button2.TabIndex = 17;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(190, 285);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(58, 23);
            this.button3.TabIndex = 18;
            this.button3.Text = "Remove";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(24, 314);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(224, 23);
            this.button4.TabIndex = 19;
            this.button4.Text = "Clear Fields";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "CID";
            this.dataGridViewTextBoxColumn6.HeaderText = "Condition ID";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "RID";
            this.dataGridViewTextBoxColumn7.HeaderText = "Resident ID";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Diabetes";
            this.dataGridViewTextBoxColumn2.HeaderText = "Diabetes";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Hypertension";
            this.dataGridViewTextBoxColumn3.HeaderText = "Hypertension";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Glaucoma";
            this.dataGridViewTextBoxColumn4.HeaderText = "Glaucoma";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Dementia";
            this.dataGridViewTextBoxColumn5.HeaderText = "Dementia";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // Condition_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(845, 361);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbl_ConDetailsDataGridView);
            this.Controls.Add(diabetesLabel);
            this.Controls.Add(this.diabetesTextBox);
            this.Controls.Add(hypertensionLabel);
            this.Controls.Add(this.hypertensionTextBox);
            this.Controls.Add(glaucomaLabel);
            this.Controls.Add(this.glaucomaTextBox);
            this.Controls.Add(dementiaLabel);
            this.Controls.Add(this.dementiaTextBox);
            this.Controls.Add(cIDLabel);
            this.Controls.Add(this.cIDTextBox);
            this.Controls.Add(rIDLabel);
            this.Controls.Add(this.rIDTextBox);
            this.Controls.Add(this.tbl_ConDetailsBindingNavigator);
            this.Name = "Condition_Details";
            this.Text = "Condition_Details";
            this.Load += new System.EventHandler(this.Condition_Details_Load);
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ConDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ConDetailsBindingNavigator)).EndInit();
            this.tbl_ConDetailsBindingNavigator.ResumeLayout(false);
            this.tbl_ConDetailsBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_ConDetailsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DatabaseDataSet10 databaseDataSet10;
        private System.Windows.Forms.BindingSource tbl_ConDetailsBindingSource;
        private DatabaseDataSet10TableAdapters.tbl_ConDetailsTableAdapter tbl_ConDetailsTableAdapter;
        private DatabaseDataSet10TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tbl_ConDetailsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_ConDetailsBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox diabetesTextBox;
        private System.Windows.Forms.TextBox hypertensionTextBox;
        private System.Windows.Forms.TextBox glaucomaTextBox;
        private System.Windows.Forms.TextBox dementiaTextBox;
        private System.Windows.Forms.TextBox cIDTextBox;
        private System.Windows.Forms.TextBox rIDTextBox;
        private System.Windows.Forms.DataGridView tbl_ConDetailsDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    }
}