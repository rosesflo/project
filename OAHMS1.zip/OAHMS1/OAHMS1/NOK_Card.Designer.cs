﻿namespace OAHMS1
{
    partial class NOK_Card
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label fNameLabel;
            System.Windows.Forms.Label lNameLabel;
            System.Windows.Forms.Label addr1Label;
            System.Windows.Forms.Label addr2Label;
            System.Windows.Forms.Label telephoneLabel;
            System.Windows.Forms.Label mobileLabel;
            System.Windows.Forms.Label rWResidentLabel;
            System.Windows.Forms.Label rIDLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NOK_Card));
            this.databaseDataSet13 = new OAHMS1.DatabaseDataSet13();
            this.tbl_NOKBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_NOKTableAdapter = new OAHMS1.DatabaseDataSet13TableAdapters.tbl_NOKTableAdapter();
            this.tableAdapterManager = new OAHMS1.DatabaseDataSet13TableAdapters.TableAdapterManager();
            this.tbl_NOKBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_NOKBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.fNameTextBox = new System.Windows.Forms.TextBox();
            this.lNameTextBox = new System.Windows.Forms.TextBox();
            this.addr1TextBox = new System.Windows.Forms.TextBox();
            this.addr2TextBox = new System.Windows.Forms.TextBox();
            this.telephoneTextBox = new System.Windows.Forms.TextBox();
            this.mobileTextBox = new System.Windows.Forms.TextBox();
            this.rWResidentTextBox = new System.Windows.Forms.TextBox();
            this.rIDTextBox = new System.Windows.Forms.TextBox();
            this.tbl_NOKDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            fNameLabel = new System.Windows.Forms.Label();
            lNameLabel = new System.Windows.Forms.Label();
            addr1Label = new System.Windows.Forms.Label();
            addr2Label = new System.Windows.Forms.Label();
            telephoneLabel = new System.Windows.Forms.Label();
            mobileLabel = new System.Windows.Forms.Label();
            rWResidentLabel = new System.Windows.Forms.Label();
            rIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_NOKBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_NOKBindingNavigator)).BeginInit();
            this.tbl_NOKBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_NOKDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // fNameLabel
            // 
            fNameLabel.AutoSize = true;
            fNameLabel.Location = new System.Drawing.Point(33, 60);
            fNameLabel.Name = "fNameLabel";
            fNameLabel.Size = new System.Drawing.Size(60, 13);
            fNameLabel.TabIndex = 3;
            fNameLabel.Text = "First Name:";
            // 
            // lNameLabel
            // 
            lNameLabel.AutoSize = true;
            lNameLabel.Location = new System.Drawing.Point(33, 86);
            lNameLabel.Name = "lNameLabel";
            lNameLabel.Size = new System.Drawing.Size(61, 13);
            lNameLabel.TabIndex = 5;
            lNameLabel.Text = "Last Name:";
            // 
            // addr1Label
            // 
            addr1Label.AutoSize = true;
            addr1Label.Location = new System.Drawing.Point(33, 112);
            addr1Label.Name = "addr1Label";
            addr1Label.Size = new System.Drawing.Size(48, 13);
            addr1Label.TabIndex = 7;
            addr1Label.Text = "Address:";
            // 
            // addr2Label
            // 
            addr2Label.AutoSize = true;
            addr2Label.Location = new System.Drawing.Point(33, 138);
            addr2Label.Name = "addr2Label";
            addr2Label.Size = new System.Drawing.Size(48, 13);
            addr2Label.TabIndex = 9;
            addr2Label.Text = "Address:";
            // 
            // telephoneLabel
            // 
            telephoneLabel.AutoSize = true;
            telephoneLabel.Location = new System.Drawing.Point(33, 164);
            telephoneLabel.Name = "telephoneLabel";
            telephoneLabel.Size = new System.Drawing.Size(61, 13);
            telephoneLabel.TabIndex = 11;
            telephoneLabel.Text = "Telephone:";
            // 
            // mobileLabel
            // 
            mobileLabel.AutoSize = true;
            mobileLabel.Location = new System.Drawing.Point(33, 190);
            mobileLabel.Name = "mobileLabel";
            mobileLabel.Size = new System.Drawing.Size(41, 13);
            mobileLabel.TabIndex = 13;
            mobileLabel.Text = "Mobile:";
            // 
            // rWResidentLabel
            // 
            rWResidentLabel.AutoSize = true;
            rWResidentLabel.Location = new System.Drawing.Point(33, 216);
            rWResidentLabel.Name = "rWResidentLabel";
            rWResidentLabel.Size = new System.Drawing.Size(68, 13);
            rWResidentLabel.TabIndex = 15;
            rWResidentLabel.Text = "Relationship:";
            // 
            // rIDLabel
            // 
            rIDLabel.AutoSize = true;
            rIDLabel.Location = new System.Drawing.Point(33, 242);
            rIDLabel.Name = "rIDLabel";
            rIDLabel.Size = new System.Drawing.Size(66, 13);
            rIDLabel.TabIndex = 17;
            rIDLabel.Text = "Resident ID:";
            // 
            // databaseDataSet13
            // 
            this.databaseDataSet13.DataSetName = "DatabaseDataSet13";
            this.databaseDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_NOKBindingSource
            // 
            this.tbl_NOKBindingSource.DataMember = "tbl_NOK";
            this.tbl_NOKBindingSource.DataSource = this.databaseDataSet13;
            // 
            // tbl_NOKTableAdapter
            // 
            this.tbl_NOKTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbl_NOKTableAdapter = this.tbl_NOKTableAdapter;
            this.tableAdapterManager.UpdateOrder = OAHMS1.DatabaseDataSet13TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tbl_NOKBindingNavigator
            // 
            this.tbl_NOKBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_NOKBindingNavigator.BindingSource = this.tbl_NOKBindingSource;
            this.tbl_NOKBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_NOKBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_NOKBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_NOKBindingNavigatorSaveItem});
            this.tbl_NOKBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tbl_NOKBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_NOKBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_NOKBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_NOKBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_NOKBindingNavigator.Name = "tbl_NOKBindingNavigator";
            this.tbl_NOKBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_NOKBindingNavigator.Size = new System.Drawing.Size(827, 25);
            this.tbl_NOKBindingNavigator.TabIndex = 0;
            this.tbl_NOKBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_NOKBindingNavigatorSaveItem
            // 
            this.tbl_NOKBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbl_NOKBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_NOKBindingNavigatorSaveItem.Image")));
            this.tbl_NOKBindingNavigatorSaveItem.Name = "tbl_NOKBindingNavigatorSaveItem";
            this.tbl_NOKBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tbl_NOKBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_NOKBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_NOKBindingNavigatorSaveItem_Click);
            // 
            // fNameTextBox
            // 
            this.fNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_NOKBindingSource, "FName", true));
            this.fNameTextBox.Location = new System.Drawing.Point(110, 57);
            this.fNameTextBox.Name = "fNameTextBox";
            this.fNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.fNameTextBox.TabIndex = 4;
            // 
            // lNameTextBox
            // 
            this.lNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_NOKBindingSource, "LName", true));
            this.lNameTextBox.Location = new System.Drawing.Point(110, 83);
            this.lNameTextBox.Name = "lNameTextBox";
            this.lNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lNameTextBox.TabIndex = 6;
            // 
            // addr1TextBox
            // 
            this.addr1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_NOKBindingSource, "Addr1", true));
            this.addr1TextBox.Location = new System.Drawing.Point(110, 109);
            this.addr1TextBox.Name = "addr1TextBox";
            this.addr1TextBox.Size = new System.Drawing.Size(100, 20);
            this.addr1TextBox.TabIndex = 8;
            // 
            // addr2TextBox
            // 
            this.addr2TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_NOKBindingSource, "Addr2", true));
            this.addr2TextBox.Location = new System.Drawing.Point(110, 135);
            this.addr2TextBox.Name = "addr2TextBox";
            this.addr2TextBox.Size = new System.Drawing.Size(100, 20);
            this.addr2TextBox.TabIndex = 10;
            // 
            // telephoneTextBox
            // 
            this.telephoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_NOKBindingSource, "Telephone", true));
            this.telephoneTextBox.Location = new System.Drawing.Point(110, 161);
            this.telephoneTextBox.Name = "telephoneTextBox";
            this.telephoneTextBox.Size = new System.Drawing.Size(100, 20);
            this.telephoneTextBox.TabIndex = 12;
            // 
            // mobileTextBox
            // 
            this.mobileTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_NOKBindingSource, "Mobile", true));
            this.mobileTextBox.Location = new System.Drawing.Point(110, 187);
            this.mobileTextBox.Name = "mobileTextBox";
            this.mobileTextBox.Size = new System.Drawing.Size(100, 20);
            this.mobileTextBox.TabIndex = 14;
            // 
            // rWResidentTextBox
            // 
            this.rWResidentTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_NOKBindingSource, "RWResident", true));
            this.rWResidentTextBox.Location = new System.Drawing.Point(110, 213);
            this.rWResidentTextBox.Name = "rWResidentTextBox";
            this.rWResidentTextBox.Size = new System.Drawing.Size(100, 20);
            this.rWResidentTextBox.TabIndex = 16;
            // 
            // rIDTextBox
            // 
            this.rIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_NOKBindingSource, "RID", true));
            this.rIDTextBox.Location = new System.Drawing.Point(110, 239);
            this.rIDTextBox.Name = "rIDTextBox";
            this.rIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.rIDTextBox.TabIndex = 18;
            // 
            // tbl_NOKDataGridView
            // 
            this.tbl_NOKDataGridView.AutoGenerateColumns = false;
            this.tbl_NOKDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_NOKDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.tbl_NOKDataGridView.DataSource = this.tbl_NOKBindingSource;
            this.tbl_NOKDataGridView.Location = new System.Drawing.Point(261, 53);
            this.tbl_NOKDataGridView.Name = "tbl_NOKDataGridView";
            this.tbl_NOKDataGridView.Size = new System.Drawing.Size(533, 302);
            this.tbl_NOKDataGridView.TabIndex = 19;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(25, 303);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 23);
            this.button1.TabIndex = 20;
            this.button1.Text = "Add New Record";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(133, 303);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(49, 23);
            this.button2.TabIndex = 21;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(188, 303);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(55, 23);
            this.button3.TabIndex = 22;
            this.button3.Text = "Remove";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(23, 332);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(220, 23);
            this.button4.TabIndex = 23;
            this.button4.Text = "Clear Fields";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "FName";
            this.dataGridViewTextBoxColumn2.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "LName";
            this.dataGridViewTextBoxColumn3.HeaderText = "Last Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Addr1";
            this.dataGridViewTextBoxColumn4.HeaderText = "Address";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Addr2";
            this.dataGridViewTextBoxColumn5.HeaderText = "Address";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Telephone";
            this.dataGridViewTextBoxColumn6.HeaderText = "Telephone";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Mobile";
            this.dataGridViewTextBoxColumn7.HeaderText = "Mobile";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "RWResident";
            this.dataGridViewTextBoxColumn8.HeaderText = "Relationship";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "RID";
            this.dataGridViewTextBoxColumn9.HeaderText = "Resident ID";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // NOK_Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 385);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbl_NOKDataGridView);
            this.Controls.Add(fNameLabel);
            this.Controls.Add(this.fNameTextBox);
            this.Controls.Add(lNameLabel);
            this.Controls.Add(this.lNameTextBox);
            this.Controls.Add(addr1Label);
            this.Controls.Add(this.addr1TextBox);
            this.Controls.Add(addr2Label);
            this.Controls.Add(this.addr2TextBox);
            this.Controls.Add(telephoneLabel);
            this.Controls.Add(this.telephoneTextBox);
            this.Controls.Add(mobileLabel);
            this.Controls.Add(this.mobileTextBox);
            this.Controls.Add(rWResidentLabel);
            this.Controls.Add(this.rWResidentTextBox);
            this.Controls.Add(rIDLabel);
            this.Controls.Add(this.rIDTextBox);
            this.Controls.Add(this.tbl_NOKBindingNavigator);
            this.Name = "NOK_Card";
            this.Text = "NOK_Card";
            this.Load += new System.EventHandler(this.NOK_Card_Load);
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_NOKBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_NOKBindingNavigator)).EndInit();
            this.tbl_NOKBindingNavigator.ResumeLayout(false);
            this.tbl_NOKBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_NOKDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DatabaseDataSet13 databaseDataSet13;
        private System.Windows.Forms.BindingSource tbl_NOKBindingSource;
        private DatabaseDataSet13TableAdapters.tbl_NOKTableAdapter tbl_NOKTableAdapter;
        private DatabaseDataSet13TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tbl_NOKBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_NOKBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox fNameTextBox;
        private System.Windows.Forms.TextBox lNameTextBox;
        private System.Windows.Forms.TextBox addr1TextBox;
        private System.Windows.Forms.TextBox addr2TextBox;
        private System.Windows.Forms.TextBox telephoneTextBox;
        private System.Windows.Forms.TextBox mobileTextBox;
        private System.Windows.Forms.TextBox rWResidentTextBox;
        private System.Windows.Forms.TextBox rIDTextBox;
        private System.Windows.Forms.DataGridView tbl_NOKDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    }
}