﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Room_Card : Form
    {
        public Room_Card()
        {
            InitializeComponent();
        }

        private void tbl_RoomBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_RoomBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet15);

        }

        private void Room_Card_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet15.tbl_Room' table. You can move, or remove it, as needed.
            this.tbl_RoomTableAdapter.Fill(this.databaseDataSet15.tbl_Room);

        }
    }
}
