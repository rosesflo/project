﻿namespace OAHMS1
{
    partial class Medical_Practitioner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label daysAvailableLabel;
            System.Windows.Forms.Label timeAvailableLabel;
            System.Windows.Forms.Label fNameLabel;
            System.Windows.Forms.Label lNameLabel;
            System.Windows.Forms.Label volunteerStaffLabel;
            System.Windows.Forms.Label specialisationLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Medical_Practitioner));
            this.databaseDataSet11 = new OAHMS1.DatabaseDataSet11();
            this.tbl_MedicalPractitionerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_MedicalPractitionerTableAdapter = new OAHMS1.DatabaseDataSet11TableAdapters.tbl_MedicalPractitionerTableAdapter();
            this.tableAdapterManager = new OAHMS1.DatabaseDataSet11TableAdapters.TableAdapterManager();
            this.tbl_MedicalPractitionerBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_MedicalPractitionerBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.daysAvailableDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.fNameTextBox = new System.Windows.Forms.TextBox();
            this.lNameTextBox = new System.Windows.Forms.TextBox();
            this.volunteerStaffTextBox = new System.Windows.Forms.TextBox();
            this.specialisationTextBox = new System.Windows.Forms.TextBox();
            this.tbl_MedicalPractitionerDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            daysAvailableLabel = new System.Windows.Forms.Label();
            timeAvailableLabel = new System.Windows.Forms.Label();
            fNameLabel = new System.Windows.Forms.Label();
            lNameLabel = new System.Windows.Forms.Label();
            volunteerStaffLabel = new System.Windows.Forms.Label();
            specialisationLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_MedicalPractitionerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_MedicalPractitionerBindingNavigator)).BeginInit();
            this.tbl_MedicalPractitionerBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_MedicalPractitionerDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // daysAvailableLabel
            // 
            daysAvailableLabel.AutoSize = true;
            daysAvailableLabel.Location = new System.Drawing.Point(26, 63);
            daysAvailableLabel.Name = "daysAvailableLabel";
            daysAvailableLabel.Size = new System.Drawing.Size(80, 13);
            daysAvailableLabel.TabIndex = 3;
            daysAvailableLabel.Text = "Days Available:";
            // 
            // timeAvailableLabel
            // 
            timeAvailableLabel.AutoSize = true;
            timeAvailableLabel.Location = new System.Drawing.Point(26, 88);
            timeAvailableLabel.Name = "timeAvailableLabel";
            timeAvailableLabel.Size = new System.Drawing.Size(79, 13);
            timeAvailableLabel.TabIndex = 5;
            timeAvailableLabel.Text = "Time Available:";
            // 
            // fNameLabel
            // 
            fNameLabel.AutoSize = true;
            fNameLabel.Location = new System.Drawing.Point(26, 114);
            fNameLabel.Name = "fNameLabel";
            fNameLabel.Size = new System.Drawing.Size(60, 13);
            fNameLabel.TabIndex = 7;
            fNameLabel.Text = "First Name:";
            // 
            // lNameLabel
            // 
            lNameLabel.AutoSize = true;
            lNameLabel.Location = new System.Drawing.Point(26, 140);
            lNameLabel.Name = "lNameLabel";
            lNameLabel.Size = new System.Drawing.Size(61, 13);
            lNameLabel.TabIndex = 9;
            lNameLabel.Text = "Last Name:";
            // 
            // volunteerStaffLabel
            // 
            volunteerStaffLabel.AutoSize = true;
            volunteerStaffLabel.Location = new System.Drawing.Point(26, 166);
            volunteerStaffLabel.Name = "volunteerStaffLabel";
            volunteerStaffLabel.Size = new System.Drawing.Size(80, 13);
            volunteerStaffLabel.TabIndex = 11;
            volunteerStaffLabel.Text = "Volunteer Staff:";
            // 
            // specialisationLabel
            // 
            specialisationLabel.AutoSize = true;
            specialisationLabel.Location = new System.Drawing.Point(26, 192);
            specialisationLabel.Name = "specialisationLabel";
            specialisationLabel.Size = new System.Drawing.Size(75, 13);
            specialisationLabel.TabIndex = 13;
            specialisationLabel.Text = "Specialisation:";
            // 
            // databaseDataSet11
            // 
            this.databaseDataSet11.DataSetName = "DatabaseDataSet11";
            this.databaseDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_MedicalPractitionerBindingSource
            // 
            this.tbl_MedicalPractitionerBindingSource.DataMember = "tbl_MedicalPractitioner";
            this.tbl_MedicalPractitionerBindingSource.DataSource = this.databaseDataSet11;
            // 
            // tbl_MedicalPractitionerTableAdapter
            // 
            this.tbl_MedicalPractitionerTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbl_MedicalPractitionerTableAdapter = this.tbl_MedicalPractitionerTableAdapter;
            this.tableAdapterManager.UpdateOrder = OAHMS1.DatabaseDataSet11TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tbl_MedicalPractitionerBindingNavigator
            // 
            this.tbl_MedicalPractitionerBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_MedicalPractitionerBindingNavigator.BindingSource = this.tbl_MedicalPractitionerBindingSource;
            this.tbl_MedicalPractitionerBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_MedicalPractitionerBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_MedicalPractitionerBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_MedicalPractitionerBindingNavigatorSaveItem});
            this.tbl_MedicalPractitionerBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tbl_MedicalPractitionerBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_MedicalPractitionerBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_MedicalPractitionerBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_MedicalPractitionerBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_MedicalPractitionerBindingNavigator.Name = "tbl_MedicalPractitionerBindingNavigator";
            this.tbl_MedicalPractitionerBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_MedicalPractitionerBindingNavigator.Size = new System.Drawing.Size(837, 25);
            this.tbl_MedicalPractitionerBindingNavigator.TabIndex = 0;
            this.tbl_MedicalPractitionerBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_MedicalPractitionerBindingNavigatorSaveItem
            // 
            this.tbl_MedicalPractitionerBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbl_MedicalPractitionerBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_MedicalPractitionerBindingNavigatorSaveItem.Image")));
            this.tbl_MedicalPractitionerBindingNavigatorSaveItem.Name = "tbl_MedicalPractitionerBindingNavigatorSaveItem";
            this.tbl_MedicalPractitionerBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tbl_MedicalPractitionerBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_MedicalPractitionerBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_MedicalPractitionerBindingNavigatorSaveItem_Click);
            // 
            // daysAvailableDateTimePicker
            // 
            this.daysAvailableDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tbl_MedicalPractitionerBindingSource, "DaysAvailable", true));
            this.daysAvailableDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.daysAvailableDateTimePicker.Location = new System.Drawing.Point(112, 59);
            this.daysAvailableDateTimePicker.Name = "daysAvailableDateTimePicker";
            this.daysAvailableDateTimePicker.Size = new System.Drawing.Size(113, 20);
            this.daysAvailableDateTimePicker.TabIndex = 4;
            // 
            // fNameTextBox
            // 
            this.fNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_MedicalPractitionerBindingSource, "FName", true));
            this.fNameTextBox.Location = new System.Drawing.Point(112, 111);
            this.fNameTextBox.Name = "fNameTextBox";
            this.fNameTextBox.Size = new System.Drawing.Size(200, 20);
            this.fNameTextBox.TabIndex = 8;
            // 
            // lNameTextBox
            // 
            this.lNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_MedicalPractitionerBindingSource, "LName", true));
            this.lNameTextBox.Location = new System.Drawing.Point(112, 137);
            this.lNameTextBox.Name = "lNameTextBox";
            this.lNameTextBox.Size = new System.Drawing.Size(200, 20);
            this.lNameTextBox.TabIndex = 10;
            // 
            // volunteerStaffTextBox
            // 
            this.volunteerStaffTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_MedicalPractitionerBindingSource, "VolunteerStaff", true));
            this.volunteerStaffTextBox.Location = new System.Drawing.Point(112, 163);
            this.volunteerStaffTextBox.Name = "volunteerStaffTextBox";
            this.volunteerStaffTextBox.Size = new System.Drawing.Size(113, 20);
            this.volunteerStaffTextBox.TabIndex = 12;
            // 
            // specialisationTextBox
            // 
            this.specialisationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_MedicalPractitionerBindingSource, "Specialisation", true));
            this.specialisationTextBox.Location = new System.Drawing.Point(112, 189);
            this.specialisationTextBox.Name = "specialisationTextBox";
            this.specialisationTextBox.Size = new System.Drawing.Size(200, 20);
            this.specialisationTextBox.TabIndex = 14;
            // 
            // tbl_MedicalPractitionerDataGridView
            // 
            this.tbl_MedicalPractitionerDataGridView.AutoGenerateColumns = false;
            this.tbl_MedicalPractitionerDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_MedicalPractitionerDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.tbl_MedicalPractitionerDataGridView.DataSource = this.tbl_MedicalPractitionerBindingSource;
            this.tbl_MedicalPractitionerDataGridView.Location = new System.Drawing.Point(332, 58);
            this.tbl_MedicalPractitionerDataGridView.Name = "tbl_MedicalPractitionerDataGridView";
            this.tbl_MedicalPractitionerDataGridView.Size = new System.Drawing.Size(505, 256);
            this.tbl_MedicalPractitionerDataGridView.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(25, 258);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Add New Record";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(129, 258);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 23);
            this.button2.TabIndex = 17;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(195, 258);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 18;
            this.button3.Text = "Remove";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(27, 287);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(243, 23);
            this.button4.TabIndex = 19;
            this.button4.Text = "Clear Fields";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker1.Location = new System.Drawing.Point(112, 84);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(113, 20);
            this.dateTimePicker1.TabIndex = 20;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "DaysAvailable";
            this.dataGridViewTextBoxColumn2.HeaderText = "Days Available";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "TimeAvailable";
            this.dataGridViewTextBoxColumn3.HeaderText = "Time Available";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "FName";
            this.dataGridViewTextBoxColumn4.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "LName";
            this.dataGridViewTextBoxColumn5.HeaderText = "Last Name";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "VolunteerStaff";
            this.dataGridViewTextBoxColumn6.HeaderText = "Volunteer Staff";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Specialisation";
            this.dataGridViewTextBoxColumn7.HeaderText = "Specialisation";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // Medical_Practitioner
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 355);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbl_MedicalPractitionerDataGridView);
            this.Controls.Add(daysAvailableLabel);
            this.Controls.Add(this.daysAvailableDateTimePicker);
            this.Controls.Add(timeAvailableLabel);
            this.Controls.Add(fNameLabel);
            this.Controls.Add(this.fNameTextBox);
            this.Controls.Add(lNameLabel);
            this.Controls.Add(this.lNameTextBox);
            this.Controls.Add(volunteerStaffLabel);
            this.Controls.Add(this.volunteerStaffTextBox);
            this.Controls.Add(specialisationLabel);
            this.Controls.Add(this.specialisationTextBox);
            this.Controls.Add(this.tbl_MedicalPractitionerBindingNavigator);
            this.Name = "Medical_Practitioner";
            this.Text = "Medical_Practitioner";
            this.Load += new System.EventHandler(this.Medical_Practitioner_Load);
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_MedicalPractitionerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_MedicalPractitionerBindingNavigator)).EndInit();
            this.tbl_MedicalPractitionerBindingNavigator.ResumeLayout(false);
            this.tbl_MedicalPractitionerBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_MedicalPractitionerDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DatabaseDataSet11 databaseDataSet11;
        private System.Windows.Forms.BindingSource tbl_MedicalPractitionerBindingSource;
        private DatabaseDataSet11TableAdapters.tbl_MedicalPractitionerTableAdapter tbl_MedicalPractitionerTableAdapter;
        private DatabaseDataSet11TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tbl_MedicalPractitionerBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_MedicalPractitionerBindingNavigatorSaveItem;
        private System.Windows.Forms.DateTimePicker daysAvailableDateTimePicker;
        private System.Windows.Forms.TextBox fNameTextBox;
        private System.Windows.Forms.TextBox lNameTextBox;
        private System.Windows.Forms.TextBox volunteerStaffTextBox;
        private System.Windows.Forms.TextBox specialisationTextBox;
        private System.Windows.Forms.DataGridView tbl_MedicalPractitionerDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}