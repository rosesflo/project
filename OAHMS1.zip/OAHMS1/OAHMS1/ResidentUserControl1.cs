﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OAHMS1
{
    public partial class ResidentUserControl1 : UserControl
    {

        private static ResidentUserControl1 _instance;

        public static ResidentUserControl1 Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ResidentUserControl1();
                return _instance;
            }
        }
        public ResidentUserControl1()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\Documents\LocalDB\OAHMS1\OAHMS1\Database.mdf;Integrated Security=True;");


        private void ResidentUserControl1_Load(object sender, EventArgs e)
        {
            refresh_DataGridView();//call function
        }


        public void refresh_DataGridView()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ShowResidents_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("        <<<Invalid SQL Operation>>>>: \n" + ex);
                }
                con.Close();

                dataGridView1.DataSource = ds.Tables[0];

                this.dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                this.dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                this.dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[9].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);

            }
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("ResidentAdd_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@R_Id", txtResID.Text);
            cmd.Parameters.AddWithValue("@Name", txtName.Text);
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Religion", txtReligion.Text);
            cmd.Parameters.AddWithValue("@Allergies", txtAllergies.Text);
            cmd.Parameters.AddWithValue("@Contact", txtContact.Text);
            cmd.Parameters.AddWithValue("@Sex", txtSex);
            cmd.Parameters.AddWithValue("@DateOfBirth", dtpDOB.Text);
            cmd.Parameters.AddWithValue("@MaritalStatus", txtStatus);
            cmd.Parameters.AddWithValue("@RM_Num", txtRNum.Text);

            con.Open();

            try
            {
                cmd.ExecuteNonQuery(); //catch SQL Exceptions
            }
            catch (Exception ex)
            {
                MessageBox.Show("        <<<Invalid SQL Operation>>>>: \n" + ex);
            }
            con.Close();

            refresh_DataGridView();//refresh after every addition
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ResidentDelete_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@R_Id", txtResID.Text);

                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("        <<<Invalid SQL Operation>>>>: \n" + ex);
                }
                con.Close();

                refresh_DataGridView();
            }
            catch (Exception ex) //outer catch block C# exception
            {

                {
                    MessageBox.Show("" + ex);

                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResID.Text = "";
            txtName.Text = "";
            txtAddress.Text = "";
            txtReligion.Text = "";
            txtAllergies.Text = "";
            txtContact.Text = "";
            txtSex.Text = "";
            dtpDOB.Text = "";
            txtStatus.Text = "";
            txtRNum.Text = "";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ResidentSearch_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@R_Id", txtResID.Text);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("        <<<Invalid SQL Operation>>>>: \n" + ex);
                }
                con.Close();

                dataGridView1.DataSource = ds.Tables[0];

                this.dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                this.dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                this.dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[9].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }
    }
}

    
    
        




