﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OAHMS1
{
    public partial class Service_Card : Form
    {
        public Service_Card()
        {
            InitializeComponent();
        }

        private void tbl_ServiceBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_ServiceBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet9);

        }

        private void Service_Card_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet9.tbl_Service' table. You can move, or remove it, as needed.
            this.tbl_ServiceTableAdapter.Fill(this.databaseDataSet9.tbl_Service);

        }
    }
}
