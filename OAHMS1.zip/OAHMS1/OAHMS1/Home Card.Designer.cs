﻿namespace OAHMS1
{
    partial class Home_Card
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label addr1Label;
            System.Windows.Forms.Label addr2Label;
            System.Windows.Forms.Label telephoneLabel;
            System.Windows.Forms.Label registrationNoLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home_Card));
            this.databaseDataSet8 = new OAHMS1.DatabaseDataSet8();
            this.tbl_HomeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_HomeTableAdapter = new OAHMS1.DatabaseDataSet8TableAdapters.tbl_HomeTableAdapter();
            this.tableAdapterManager = new OAHMS1.DatabaseDataSet8TableAdapters.TableAdapterManager();
            this.tbl_HomeBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_HomeBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.addr1TextBox = new System.Windows.Forms.TextBox();
            this.addr2TextBox = new System.Windows.Forms.TextBox();
            this.telephoneTextBox = new System.Windows.Forms.TextBox();
            this.registrationNoTextBox = new System.Windows.Forms.TextBox();
            this.tbl_HomeDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            nameLabel = new System.Windows.Forms.Label();
            addr1Label = new System.Windows.Forms.Label();
            addr2Label = new System.Windows.Forms.Label();
            telephoneLabel = new System.Windows.Forms.Label();
            registrationNoLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_HomeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_HomeBindingNavigator)).BeginInit();
            this.tbl_HomeBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_HomeDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(33, 64);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(38, 13);
            nameLabel.TabIndex = 3;
            nameLabel.Text = "Name:";
            // 
            // addr1Label
            // 
            addr1Label.AutoSize = true;
            addr1Label.Location = new System.Drawing.Point(33, 90);
            addr1Label.Name = "addr1Label";
            addr1Label.Size = new System.Drawing.Size(48, 13);
            addr1Label.TabIndex = 5;
            addr1Label.Text = "Address:";
            // 
            // addr2Label
            // 
            addr2Label.AutoSize = true;
            addr2Label.Location = new System.Drawing.Point(33, 116);
            addr2Label.Name = "addr2Label";
            addr2Label.Size = new System.Drawing.Size(48, 13);
            addr2Label.TabIndex = 7;
            addr2Label.Text = "Address:";
            // 
            // telephoneLabel
            // 
            telephoneLabel.AutoSize = true;
            telephoneLabel.Location = new System.Drawing.Point(33, 142);
            telephoneLabel.Name = "telephoneLabel";
            telephoneLabel.Size = new System.Drawing.Size(61, 13);
            telephoneLabel.TabIndex = 9;
            telephoneLabel.Text = "Telephone:";
            // 
            // registrationNoLabel
            // 
            registrationNoLabel.AutoSize = true;
            registrationNoLabel.Location = new System.Drawing.Point(33, 168);
            registrationNoLabel.Name = "registrationNoLabel";
            registrationNoLabel.Size = new System.Drawing.Size(83, 13);
            registrationNoLabel.TabIndex = 11;
            registrationNoLabel.Text = "Registration No:";
            // 
            // databaseDataSet8
            // 
            this.databaseDataSet8.DataSetName = "DatabaseDataSet8";
            this.databaseDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_HomeBindingSource
            // 
            this.tbl_HomeBindingSource.DataMember = "tbl_Home";
            this.tbl_HomeBindingSource.DataSource = this.databaseDataSet8;
            // 
            // tbl_HomeTableAdapter
            // 
            this.tbl_HomeTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbl_HomeTableAdapter = this.tbl_HomeTableAdapter;
            this.tableAdapterManager.UpdateOrder = OAHMS1.DatabaseDataSet8TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tbl_HomeBindingNavigator
            // 
            this.tbl_HomeBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_HomeBindingNavigator.BindingSource = this.tbl_HomeBindingSource;
            this.tbl_HomeBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_HomeBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_HomeBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_HomeBindingNavigatorSaveItem});
            this.tbl_HomeBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tbl_HomeBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_HomeBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_HomeBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_HomeBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_HomeBindingNavigator.Name = "tbl_HomeBindingNavigator";
            this.tbl_HomeBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_HomeBindingNavigator.Size = new System.Drawing.Size(813, 25);
            this.tbl_HomeBindingNavigator.TabIndex = 0;
            this.tbl_HomeBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_HomeBindingNavigatorSaveItem
            // 
            this.tbl_HomeBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbl_HomeBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_HomeBindingNavigatorSaveItem.Image")));
            this.tbl_HomeBindingNavigatorSaveItem.Name = "tbl_HomeBindingNavigatorSaveItem";
            this.tbl_HomeBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tbl_HomeBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_HomeBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_HomeBindingNavigatorSaveItem_Click);
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_HomeBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(122, 61);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 4;
            // 
            // addr1TextBox
            // 
            this.addr1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_HomeBindingSource, "Addr1", true));
            this.addr1TextBox.Location = new System.Drawing.Point(122, 87);
            this.addr1TextBox.Name = "addr1TextBox";
            this.addr1TextBox.Size = new System.Drawing.Size(100, 20);
            this.addr1TextBox.TabIndex = 6;
            // 
            // addr2TextBox
            // 
            this.addr2TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_HomeBindingSource, "Addr2", true));
            this.addr2TextBox.Location = new System.Drawing.Point(122, 113);
            this.addr2TextBox.Name = "addr2TextBox";
            this.addr2TextBox.Size = new System.Drawing.Size(100, 20);
            this.addr2TextBox.TabIndex = 8;
            // 
            // telephoneTextBox
            // 
            this.telephoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_HomeBindingSource, "Telephone", true));
            this.telephoneTextBox.Location = new System.Drawing.Point(122, 139);
            this.telephoneTextBox.Name = "telephoneTextBox";
            this.telephoneTextBox.Size = new System.Drawing.Size(100, 20);
            this.telephoneTextBox.TabIndex = 10;
            // 
            // registrationNoTextBox
            // 
            this.registrationNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_HomeBindingSource, "RegistrationNo", true));
            this.registrationNoTextBox.Location = new System.Drawing.Point(122, 165);
            this.registrationNoTextBox.Name = "registrationNoTextBox";
            this.registrationNoTextBox.Size = new System.Drawing.Size(100, 20);
            this.registrationNoTextBox.TabIndex = 12;
            // 
            // tbl_HomeDataGridView
            // 
            this.tbl_HomeDataGridView.AutoGenerateColumns = false;
            this.tbl_HomeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_HomeDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.tbl_HomeDataGridView.DataSource = this.tbl_HomeBindingSource;
            this.tbl_HomeDataGridView.Location = new System.Drawing.Point(265, 59);
            this.tbl_HomeDataGridView.Name = "tbl_HomeDataGridView";
            this.tbl_HomeDataGridView.Size = new System.Drawing.Size(536, 236);
            this.tbl_HomeDataGridView.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 243);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Add New Record";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(122, 243);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(56, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(184, 243);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 16;
            this.button3.Text = "Remove";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 272);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(247, 23);
            this.button4.TabIndex = 17;
            this.button4.Text = "Clear Fields";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Addr1";
            this.dataGridViewTextBoxColumn3.HeaderText = "Address";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Addr2";
            this.dataGridViewTextBoxColumn4.HeaderText = "Address";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Telephone";
            this.dataGridViewTextBoxColumn5.HeaderText = "Telephone";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "RegistrationNo";
            this.dataGridViewTextBoxColumn6.HeaderText = "RegistrationNo";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // Home_Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 321);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbl_HomeDataGridView);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(addr1Label);
            this.Controls.Add(this.addr1TextBox);
            this.Controls.Add(addr2Label);
            this.Controls.Add(this.addr2TextBox);
            this.Controls.Add(telephoneLabel);
            this.Controls.Add(this.telephoneTextBox);
            this.Controls.Add(registrationNoLabel);
            this.Controls.Add(this.registrationNoTextBox);
            this.Controls.Add(this.tbl_HomeBindingNavigator);
            this.Name = "Home_Card";
            this.Text = "Home_Card";
            this.Load += new System.EventHandler(this.Home_Card_Load);
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_HomeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_HomeBindingNavigator)).EndInit();
            this.tbl_HomeBindingNavigator.ResumeLayout(false);
            this.tbl_HomeBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_HomeDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DatabaseDataSet8 databaseDataSet8;
        private System.Windows.Forms.BindingSource tbl_HomeBindingSource;
        private DatabaseDataSet8TableAdapters.tbl_HomeTableAdapter tbl_HomeTableAdapter;
        private DatabaseDataSet8TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tbl_HomeBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_HomeBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox addr1TextBox;
        private System.Windows.Forms.TextBox addr2TextBox;
        private System.Windows.Forms.TextBox telephoneTextBox;
        private System.Windows.Forms.TextBox registrationNoTextBox;
        private System.Windows.Forms.DataGridView tbl_HomeDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}